import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  onAuthStateChanged,
  sendEmailVerification,
  sendPasswordResetEmail,
  signOut,
  type User,
} from 'firebase/auth';
import { get, onValue, push, ref, runTransaction, set, update } from 'firebase/database';
import { auth, db } from './firebase';
import type {
  AdminSettings,
  CartItem,
  CategoryDef,
  CustomerProfile,
  DeliveryPartner,
  FeedbackItem,
  MenuItem,
  OrderRecord,
  ProductReview,
  Store,
  TabKey,
  WalletTransaction,
} from './types/bazar';
import {
  DEFAULT_CATEGORIES,
  darkenHexColor,
  decodeCartFromShareParam,
  deriveGroupOrderStatus,
  doesItemMatchCategory,
  evaluateSpamRisk,
  findNearestAvailableRider,
  groupCustomerOrders,
  isValidIndianMobile,
  matchesKeywordSearch,
  mergePastOrderIntoCart,
  mergeSharedCartItems,
  normalizeOrderStatus,
  sanitizeText,
} from './utils/bazarLogic';
import {
  collectKnownUtrs,
  evaluateWalletWithdrawalSafety,
  mapAuthErrorSafe,
  reconcileCartWithCatalog,
  requiresStrictEmailVerification,
  sanitizeInputBounded,
  sanitizeStoredCartItems,
  validateUpiUtr,
} from './utils/security';
import {
  buildOrderSnapshotMap,
  detectOrderNotificationEvents,
  detectWalletNotificationEvents,
  type OrderSnapshotState,
} from './utils/notifications';
import { stepDemoRiderCoord } from './utils/miniMapLogic';
import { triggerHaptic } from './utils/haptics';
import {
  DEMO_ADMIN_SETTINGS,
  DEMO_CUSTOMER_UID,
  DEMO_FEEDBACKS,
  DEMO_MENUS,
  DEMO_ORDERS,
  DEMO_PROFILE,
  DEMO_REVIEWS,
  DEMO_RIDERS,
  DEMO_STORES,
  DEMO_WALLET_TX,
} from './utils/demoSeed';
import { usePushNotifications } from './hooks/usePushNotifications';
import { AuthScreen, EmailVerificationScreen } from './components/AuthScreen';
import { HomeTab } from './components/HomeTab';
import { OrdersTab } from './components/OrdersTab';
import { WalletTab } from './components/WalletTab';
import { ProfileTab } from './components/ProfileTab';
import { ProductDetailModal, StoreMenuModal } from './components/CatalogModals';
import {
  CancelOrderModal,
  CheckoutModal,
  FeedbackModal,
  RatingModal,
  WalletDepositModal,
  WalletWithdrawModal,
} from './components/CheckoutAndActionModals';
import {
  LivePushBanner,
  NotificationInboxModal,
  OfflineIndicator,
} from './components/PWAControls';

interface ToastItem {
  id: number;
  msg: string;
  type: 'success' | 'danger' | 'info';
}

const CART_STORAGE_KEY = 'gb_ultra_cart';
const USED_UTRS_STORAGE_KEY = 'gb_used_utrs';
const TIMELINE_TS_STORAGE_KEY = 'gb_order_timeline_ts_v1';

function loadSavedTimelineTimestamps(): Record<string, Record<string, number>> {
  try {
    const raw = localStorage.getItem(TIMELINE_TS_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as unknown;
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return {};
    return parsed as Record<string, Record<string, number>>;
  } catch {
    return {};
  }
}

function loadSavedCart(): CartItem[] {
  try {
    const raw = localStorage.getItem(CART_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as { items?: unknown };
    return sanitizeStoredCartItems(parsed.items);
  } catch {
    return [];
  }
}

function loadSavedUsedUtrs(): string[] {
  try {
    const raw = localStorage.getItem(USED_UTRS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed
      .map((v) => String(v || '').trim())
      .filter((v) => /^\d{12}$/.test(v))
      .slice(-50);
  } catch {
    return [];
  }
}

export default function App() {
  const isAutostartDemo = useMemo(() => {
    if (typeof window === 'undefined') return false;
    return new URLSearchParams(window.location.search).get('autostart') === '1';
  }, []);

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [authVerifyTick, setAuthVerifyTick] = useState(0);
  const [isCheckingVerification, setIsCheckingVerification] = useState(false);
  const [isResendingVerification, setIsResendingVerification] = useState(false);
  const [verifyResendCooldownSec, setVerifyResendCooldownSec] = useState(0);
  const [verifyStatusMsg, setVerifyStatusMsg] = useState('');
  const [verifyStatusErr, setVerifyStatusErr] = useState('');

  const activeUserSnapshot = useMemo(() => {
    void authVerifyTick;
    if (!currentUser) return null;
    if (auth.currentUser && auth.currentUser.uid === currentUser.uid) {
      return auth.currentUser;
    }
    return currentUser;
  }, [authVerifyTick, currentUser]);

  const activeUid = currentUser?.uid || (isAutostartDemo ? DEMO_CUSTOMER_UID : null);
  const isLoggedIn = Boolean(currentUser || isAutostartDemo);
  const isDemoMode = !currentUser && isAutostartDemo;
  const needsEmailVerification = requiresStrictEmailVerification({
    isDemoMode,
    user: activeUserSnapshot,
  });

  // Core Firebase states
  const [customerProfile, setCustomerProfile] = useState<CustomerProfile | null>(
    isAutostartDemo ? DEMO_PROFILE : null
  );
  const [stores, setStores] = useState<Record<string, Store>>(
    isAutostartDemo ? DEMO_STORES : {}
  );
  const [allMenus, setAllMenus] = useState<
    Record<string, Record<string, Omit<MenuItem, 'itemId' | 'storeId'>>>
  >(isAutostartDemo ? DEMO_MENUS : {});
  const [deliveryPartners, setDeliveryPartners] = useState<
    Record<string, DeliveryPartner>
  >(isAutostartDemo ? DEMO_RIDERS : {});
  const [cachedOrders, setCachedOrders] = useState<
    Record<string, Omit<OrderRecord, 'orderId'>>
  >(isAutostartDemo ? DEMO_ORDERS : {});
  const [productReviews, setProductReviews] = useState<
    Record<string, Record<string, Record<string, ProductReview>>>
  >(isAutostartDemo ? DEMO_REVIEWS : {});
  const [walletTransactions, setWalletTransactions] = useState<
    Record<string, WalletTransaction>
  >(isAutostartDemo ? DEMO_WALLET_TX : {});
  const [myFeedbacks, setMyFeedbacks] = useState<Record<string, FeedbackItem>>(
    isAutostartDemo ? DEMO_FEEDBACKS : {}
  );
  const [settings, setSettings] = useState<AdminSettings>(
    isAutostartDemo ? DEMO_ADMIN_SETTINGS : {}
  );

  // Navigation & filter states
  const [activeTab, setActiveTab] = useState<TabKey>(() => {
    if (typeof window === 'undefined') return 'home';
    const urlTab = new URLSearchParams(window.location.search).get('tab');
    if (urlTab === 'orders' || urlTab === 'wallet' || urlTab === 'profile') {
      return urlTab;
    }
    return 'home';
  });
  const [currentCategoryFilter, setCurrentCategoryFilter] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [isVoiceListening, setIsVoiceListening] = useState(false);

  // Cart & modals
  const [cartItems, setCartItems] = useState<CartItem[]>(loadSavedCart);
  const [localUsedUtrs, setLocalUsedUtrs] = useState<string[]>(loadSavedUsedUtrs);
  const [menuStoreId, setMenuStoreId] = useState<string | null>(null);
  const [detailItemRef, setDetailItemRef] = useState<{
    storeId: string;
    itemId: string;
  } | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isDepositOpen, setIsDepositOpen] = useState(false);
  const [isWithdrawOpen, setIsWithdrawOpen] = useState(false);
  const [ratingModalState, setRatingModalState] = useState<{
    mode: 'RIDER' | 'PRODUCTS';
    groupKey: string;
  } | null>(null);
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);
  const [cancelGroupKey, setCancelGroupKey] = useState<string | null>(null);
  const [isInboxOpen, setIsInboxOpen] = useState(false);

  // GPS & Async states
  const [detectedLat, setDetectedLat] = useState<number | null>(null);
  const [detectedLng, setDetectedLng] = useState<number | null>(null);
  const [detectedLocationLink, setDetectedLocationLink] = useState('');
  const [isFetchingCheckoutGps, setIsFetchingCheckoutGps] = useState(false);
  const [isDetectingProfileGps, setIsDetectingProfileGps] = useState(false);
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);

  // Toasts & Maps Quota Guard
  const [gmpQuotaExceeded, setGmpQuotaExceeded] = useState(false);
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const toastCounter = useRef(0);
  const lastBackPressRef = useRef(0);
  const lastWithdrawAtRef = useRef(0);
  const demoProgressTimersRef = useRef<Array<ReturnType<typeof setTimeout>>>([]);
  const pendingSharedCartTokenRef = useRef<string | null>(
    typeof window !== 'undefined'
      ? new URLSearchParams(window.location.search).get('cart')
      : null
  );
  const cartItemsRef = useRef<CartItem[]>(cartItems);
  cartItemsRef.current = cartItems;

  useEffect(() => {
    const onQuotaExceeded = () => setGmpQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', onQuotaExceeded);
    return () => {
      window.removeEventListener('gmp-quota-exceeded', onQuotaExceeded);
      demoProgressTimersRef.current.forEach((t) => clearTimeout(t));
      demoProgressTimersRef.current = [];
    };
  }, []);

  // In ?autostart=1 preview mode, stream live simulated GPS ticks for assigned demo riders
  useEffect(() => {
    if (!isDemoMode) return;
    let tick = 1;
    const interval = setInterval(() => {
      tick += 1;
      const storePt = {
        lat: Number(DEMO_STORES.store_1?.lat || 26.453),
        lng: Number(DEMO_STORES.store_1?.lng || 89.973),
      };
      const customerPt = {
        lat: Number(DEMO_PROFILE.lat || 26.4524),
        lng: Number(DEMO_PROFILE.lng || 89.9723),
      };
      const nextPt = stepDemoRiderCoord(storePt, customerPt, tick, 16);
      setDeliveryPartners((prev) => {
        if (!prev.rider_1) return prev;
        return {
          ...prev,
          rider_1: {
            ...prev.rider_1,
            lat: nextPt.lat,
            lng: nextPt.lng,
            lastLocationUpdate: Date.now(),
          },
        };
      });
      setCachedOrders((prev) => {
        const next: Record<string, Omit<OrderRecord, 'orderId'>> = {};
        Object.entries(prev).forEach(([id, o]) => {
          if (o.deliveryUid === 'rider_1' && o.status !== 'DELIVERED' && o.status !== 'CANCELLED') {
            next[id] = { ...o, riderLat: nextPt.lat, riderLng: nextPt.lng };
          } else {
            next[id] = o;
          }
        });
        return next;
      });
    }, 2200);
    return () => clearInterval(interval);
  }, [isDemoMode]);

  const showToast = useCallback(
    (msg: string, type: 'success' | 'danger' | 'info' = 'success') => {
      const id = ++toastCounter.current;
      setToasts((prev) => [...prev.filter((t) => t.msg !== msg), { id, msg, type }]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 3500);
    },
    []
  );

  const switchNav = useCallback(
    (tabName: TabKey, pushHistory = true, withHaptic = false) => {
      if (withHaptic && activeTab !== tabName) {
        triggerHaptic('tap');
      }
      setActiveTab((prev) => {
        if (prev === tabName) return prev;
        if (pushHistory) {
          window.history.pushState({ screen: tabName }, '');
        }
        return tabName;
      });
    },
    [activeTab]
  );

  // Push Notifications hook
  const {
    permission: pushPermission,
    notifications,
    unreadCount,
    activeBanner,
    promptDismissed,
    enablePushNotifications,
    sendTestPush,
    pushNotification,
    markNotificationRead,
    markAllRead,
    clearInbox,
    dismissBanner,
    dismissPrompt,
  } = usePushNotifications(activeUid, isDemoMode, (tab) => switchNav(tab));

  // Persist cart
  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify({ items: cartItems }));
    } catch {
      // Ignore quota errors
    }
  }, [cartItems]);

  const recordUsedUtr = useCallback((utr: string) => {
    const clean = String(utr || '').trim();
    if (!/^\d{12}$/.test(clean)) return;
    setLocalUsedUtrs((prev) => {
      if (prev.includes(clean)) return prev;
      const next = [...prev, clean].slice(-50);
      try {
        localStorage.setItem(USED_UTRS_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // Ignore storage errors
      }
      return next;
    });
  }, []);

  // Reconcile persisted/client cart prices against authoritative live catalog
  useEffect(() => {
    if (
      cartItemsRef.current.length === 0 ||
      Object.keys(stores).length === 0 ||
      Object.keys(allMenus).length === 0
    ) {
      return;
    }
    const { safeCart, tamperedCount, removedCount } = reconcileCartWithCatalog(
      cartItemsRef.current,
      stores,
      allMenus
    );
    if (tamperedCount > 0 || removedCount > 0) {
      setCartItems(safeCart);
      showToast('🛡️ Cart prices synced to live verified store catalog.', 'info');
    }
  }, [allMenus, showToast, stores]);

  // Hydrate shared cart from ?cart=... URL parameter once catalog & session are ready
  useEffect(() => {
    const token = pendingSharedCartTokenRef.current;
    if (!token || !isLoggedIn) return;
    if (Object.keys(stores).length === 0 || Object.keys(allMenus).length === 0) {
      return;
    }

    pendingSharedCartTokenRef.current = null;
    try {
      const url = new URL(window.location.href);
      if (url.searchParams.has('cart')) {
        url.searchParams.delete('cart');
        const nextQuery = url.searchParams.toString();
        const cleanedUrl = `${url.pathname}${nextQuery ? `?${nextQuery}` : ''}${url.hash}`;
        window.history.replaceState(window.history.state, '', cleanedUrl);
      }
    } catch {
      // Ignore URL cleanup errors
    }

    const decoded = decodeCartFromShareParam(token);
    if (decoded.length === 0) {
      showToast('⚠️ Shared cart link is invalid or empty.', 'danger');
      return;
    }

    const { nextCart, addedUnits, skippedCount } = mergeSharedCartItems(
      cartItemsRef.current,
      decoded,
      stores,
      allMenus
    );

    if (addedUnits === 0) {
      showToast('⚠️ Items in this shared basket are currently unavailable.', 'danger');
      return;
    }

    setCartItems(nextCart);
    setIsCheckoutOpen(true);
    window.history.pushState({ modal: 'checkout' }, '');
    if (skippedCount > 0) {
      showToast(
        `🛍️ Loaded ${addedUnits} shared item${addedUnits > 1 ? 's' : ''} (${skippedCount} unavailable skipped)`,
        'info'
      );
    } else {
      showToast(
        `🛍️ Loaded ${addedUnits} shared item${addedUnits > 1 ? 's' : ''} into your basket!`,
        'success'
      );
    }
  }, [allMenus, isLoggedIn, showToast, stores]);

  // Derived CMS configuration
  const adminUpiId = settings.upiId || 'gossaigaonbazar@apl';
  const baseDeliveryCharge =
    settings.deliveryCharge !== undefined ? Number(settings.deliveryCharge) : 25;
  const freeDeliveryMinOrder =
    settings.freeDeliveryAbove !== undefined
      ? Number(settings.freeDeliveryAbove)
      : 299;
  const handlingFee =
    settings.handlingFee !== undefined ? Number(settings.handlingFee) : 0;
  const minOrderAmount =
    settings.minOrderAmount !== undefined ? Number(settings.minOrderAmount) : 0;

  const minCustomerDeposit =
    settings.minCustomerDeposit !== undefined
      ? Number(settings.minCustomerDeposit)
      : 50;
  const maxCustomerDeposit =
    settings.maxCustomerDeposit !== undefined
      ? Number(settings.maxCustomerDeposit)
      : 5000;
  const minCustomerWithdraw =
    settings.minCustomerWithdraw !== undefined
      ? Number(settings.minCustomerWithdraw)
      : 50;
  const maxCustomerWithdraw =
    settings.maxCustomerWithdraw !== undefined
      ? Number(settings.maxCustomerWithdraw)
      : 5000;

  const allowReferrals = settings.allowReferrals !== false;
  const referrerBonus =
    settings.referrerBonus !== undefined ? Number(settings.referrerBonus) : 25;
  const refereeBonus =
    settings.refereeBonus !== undefined ? Number(settings.refereeBonus) : 25;

  const cmsCouponCode = settings.activeCouponCode
    ? settings.activeCouponCode.toUpperCase()
    : 'GOSSAIGAON20';
  const cmsCouponDiscount = Number(settings.activeCouponDiscount || 20);
  const cmsCouponMinOrder = Number(
    settings.couponMinOrder !== undefined ? settings.couponMinOrder : 100
  );

  const allowCod = settings.allowCod !== false;
  const allowUpi = settings.allowUpi !== false;
  const allowCoupons = settings.allowCoupons !== false;
  const allowVoiceSearch = settings.allowVoiceSearch !== false;
  const maintenanceMode = settings.maintenanceMode === true;
  const maintenanceMessage =
    settings.maintenanceMessage ||
    'Gossaigaon Bazar is currently closed for maintenance. Opening soon!';

  const categories = useMemo<CategoryDef[]>(() => {
    if (Array.isArray(settings.customCategories) && settings.customCategories.length > 0) {
      const list = settings.customCategories.filter((c) => c && c.active !== false);
      if (!list.some((c) => c.id === 'ALL_STORES')) {
        list.splice(1, 0, {
          id: 'ALL_STORES',
          name: 'All Store',
          icon: '🏪',
          keywords: [],
          active: true,
        });
      }
      if (!list.some((c) => c.id === 'FAVORITES')) {
        list.splice(2, 0, {
          id: 'FAVORITES',
          name: 'Favorites',
          icon: '❤️',
          keywords: [],
          active: true,
        });
      }
      return list;
    }
    return DEFAULT_CATEGORIES;
  }, [settings.customCategories]);

  useEffect(() => {
    if (!categories.some((c) => c.id === currentCategoryFilter)) {
      setCurrentCategoryFilter('ALL');
    }
  }, [categories, currentCategoryFilter]);

  // Apply CMS Theme CSS variables
  useEffect(() => {
    const root = document.documentElement;
    if (settings.themePrimaryColor) {
      root.style.setProperty('--brand-green', settings.themePrimaryColor);
      root.style.setProperty('--primary', settings.themePrimaryColor);
      root.style.setProperty('--success', settings.themePrimaryColor);
      root.style.setProperty(
        '--brand-green-dark',
        darkenHexColor(settings.themePrimaryColor)
      );
    } else {
      root.style.setProperty('--brand-green', '#0c831f');
      root.style.setProperty('--primary', '#0c831f');
      root.style.setProperty('--success', '#0c831f');
      root.style.setProperty('--brand-green-dark', '#075e14');
    }
    if (settings.themeAccentColor) {
      root.style.setProperty('--brand-yellow', settings.themeAccentColor);
    } else {
      root.style.setProperty('--brand-yellow', '#f8cb46');
    }
    if (settings.themeBgColor) {
      root.style.setProperty('--bg', settings.themeBgColor);
    } else {
      root.style.setProperty('--bg', '#f4f6fb');
    }
    if (settings.appBrandName) {
      document.title = `${settings.appBrandName} - Express Delivery`;
    } else {
      document.title = 'Gossaigaon Bazar - 15-Minute Grocery Delivery';
    }
  }, [settings]);

  // Auth listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      setVerifyStatusMsg('');
      setVerifyStatusErr('');
      setVerifyResendCooldownSec(0);
      setAuthReady(true);
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (verifyResendCooldownSec <= 0) return undefined;
    const timer = window.setTimeout(() => {
      setVerifyResendCooldownSec((sec) => Math.max(0, sec - 1));
    }, 1000);
    return () => window.clearTimeout(timer);
  }, [verifyResendCooldownSec]);

  // Refs for diffing push notifications cleanly without duplicate triggers
  const orderSnapshotRef = useRef<Record<string, OrderSnapshotState> | null>(null);
  const ordersHydratedRef = useRef<boolean>(isAutostartDemo);
  const prevUidForSnapshotRef = useRef<string | null>(null);
  const walletKeysRef = useRef<Set<string> | null>(null);
  const lastAnnouncementRef = useRef<string | null>(null);

  // Firebase RTDB real-time listeners (with clean unsubscribe!)
  useEffect(() => {
    if (!currentUser || needsEmailVerification) return;
    const uid = currentUser.uid;
    orderSnapshotRef.current = null;
    walletKeysRef.current = null;

    const unsubs: Array<() => void> = [];

    unsubs.push(
      onValue(ref(db, `customers/${uid}`), (snap) => {
        const data = (snap.val() || {}) as CustomerProfile;
        if (!data.referralCode) {
          const code = 'GB' + uid.slice(0, 6).toUpperCase();
          void set(ref(db, `customers/${uid}/referralCode`), code);
          data.referralCode = code;
        }
        setCustomerProfile(data);
        if (data.lat && data.lng) {
          setDetectedLat(data.lat);
          setDetectedLng(data.lng);
          setDetectedLocationLink(data.locationLink || '');
        }
      })
    );

    unsubs.push(
      onValue(ref(db, 'restaurants'), (snap) => {
        setStores((snap.val() || {}) as Record<string, Store>);
      })
    );

    unsubs.push(
      onValue(ref(db, 'menus'), (snap) => {
        setAllMenus(
          (snap.val() || {}) as Record<
            string,
            Record<string, Omit<MenuItem, 'itemId' | 'storeId'>>
          >
        );
      })
    );

    unsubs.push(
      onValue(ref(db, 'productReviews'), (snap) => {
        setProductReviews(
          (snap.val() || {}) as Record<
            string,
            Record<string, Record<string, ProductReview>>
          >
        );
      })
    );

    unsubs.push(
      onValue(ref(db, `walletTransactions/${uid}`), (snap) => {
        const txMap = (snap.val() || {}) as Record<string, WalletTransaction>;
        setWalletTransactions(txMap);

        const keys = new Set(Object.keys(txMap));
        if (walletKeysRef.current !== null) {
          const newAlerts = detectWalletNotificationEvents(
            walletKeysRef.current,
            txMap
          );
          newAlerts.forEach((n) => pushNotification(n, true));
        }
        walletKeysRef.current = keys;
      })
    );

    unsubs.push(
      onValue(ref(db, 'feedbacks'), (snap) => {
        const allFb = (snap.val() || {}) as Record<string, FeedbackItem>;
        const mine: Record<string, FeedbackItem> = {};
        Object.entries(allFb).forEach(([id, f]) => {
          if (f.uid === uid) mine[id] = f;
        });
        setMyFeedbacks(mine);
      })
    );

    unsubs.push(
      onValue(ref(db, 'deliveryPartners'), (snap) => {
        setDeliveryPartners((snap.val() || {}) as Record<string, DeliveryPartner>);
      })
    );

    unsubs.push(
      onValue(ref(db, 'admin/settings'), (snap) => {
        const s = (snap.val() || {}) as AdminSettings;
        setSettings(s);
        const activeAnn =
          s.announcementActive && s.announcementText ? s.announcementText : '';
        if (
          lastAnnouncementRef.current !== null &&
          activeAnn &&
          activeAnn !== lastAnnouncementRef.current
        ) {
          pushNotification(
            {
              id: `promo_${Date.now()}`,
              title: '📢 Gossaigaon Bazar Offer Alert',
              body: activeAnn,
              tag: 'gb-announcement',
              type: 'PROMO',
              targetTab: 'home',
              createdAt: Date.now(),
              read: false,
            },
            true
          );
        }
        lastAnnouncementRef.current = activeAnn;
      })
    );

    unsubs.push(
      onValue(ref(db, 'orders'), (snap) => {
        const allOrd = (snap.val() || {}) as Record<
          string,
          Omit<OrderRecord, 'orderId'>
        >;
        const mine: Record<string, Omit<OrderRecord, 'orderId'>> = {};
        Object.entries(allOrd).forEach(([id, o]) => {
          if (o.customerUid === uid) mine[id] = o;
        });
        ordersHydratedRef.current = true;
        setCachedOrders(mine);
      })
    );

    return () => {
      ordersHydratedRef.current = false;
      unsubs.forEach((fn) => fn());
    };
  }, [currentUser, needsEmailVerification, pushNotification]);

  // Hardware back button / popstate handling
  useEffect(() => {
    window.history.replaceState({ screen: 'home' }, '');
    const handlePopState = () => {
      if (isInboxOpen) {
        setIsInboxOpen(false);
        return;
      }
      if (ratingModalState) {
        setRatingModalState(null);
        return;
      }
      if (isFeedbackOpen) {
        setIsFeedbackOpen(false);
        return;
      }
      if (isDepositOpen) {
        setIsDepositOpen(false);
        return;
      }
      if (isWithdrawOpen) {
        setIsWithdrawOpen(false);
        return;
      }
      if (cancelGroupKey) {
        setCancelGroupKey(null);
        return;
      }
      if (isCheckoutOpen) {
        setIsCheckoutOpen(false);
        return;
      }
      if (detailItemRef) {
        setDetailItemRef(null);
        return;
      }
      if (menuStoreId) {
        setMenuStoreId(null);
        return;
      }
      if (activeTab !== 'home') {
        switchNav('home', false);
        return;
      }
      const now = Date.now();
      if (now - lastBackPressRef.current < 2000) {
        window.history.back();
      } else {
        lastBackPressRef.current = now;
        showToast('Press BACK again to exit', 'info');
        window.history.pushState({ screen: 'home' }, '');
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [
    activeTab,
    cancelGroupKey,
    detailItemRef,
    isCheckoutOpen,
    isDepositOpen,
    isFeedbackOpen,
    isInboxOpen,
    isWithdrawOpen,
    menuStoreId,
    ratingModalState,
    showToast,
    switchNav,
  ]);

  // Memoized products & stores lists
  const filteredProducts = useMemo<MenuItem[]>(() => {
    const query = searchQuery.toLowerCase().trim();
    const list: MenuItem[] = [];
    Object.entries(allMenus).forEach(([storeId, storeItems]) => {
      const store = stores[storeId];
      if (
        store &&
        store.approved === true &&
        store.suspended !== true &&
        store.isOpen !== false
      ) {
        Object.entries(storeItems || {}).forEach(([itemId, item]) => {
          if (item.available !== false && item.adminApproved === true) {
            list.push({ ...item, itemId, storeId, storeName: store.name });
          }
        });
      }
    });

    return list.filter((item) => {
      if (
        currentCategoryFilter !== 'ALL' &&
        currentCategoryFilter !== 'ALL_STORES' &&
        !doesItemMatchCategory(
          item,
          currentCategoryFilter,
          categories,
          customerProfile?.favorites
        )
      ) {
        return false;
      }
      if (query && !matchesKeywordSearch(item, item.storeName || '', query)) {
        return false;
      }
      return true;
    });
  }, [
    allMenus,
    categories,
    currentCategoryFilter,
    customerProfile?.favorites,
    searchQuery,
    stores,
  ]);

  const approvedStores = useMemo(() => {
    const query = searchQuery.toLowerCase().trim();
    return Object.entries(stores).filter(([_, s]) => {
      if (s.approved !== true || s.suspended === true) return false;
      if (!query) return true;
      return (
        (s.name || '').toLowerCase().includes(query) ||
        (s.cuisine || '').toLowerCase().includes(query)
      );
    });
  }, [searchQuery, stores]);

  const [observedStatusTimestamps, setObservedStatusTimestamps] = useState<
    Record<string, Record<string, number>>
  >(loadSavedTimelineTimestamps);

  const groupedOrders = useMemo(
    () => groupCustomerOrders(cachedOrders),
    [cachedOrders]
  );

  // Unified real-time order-status push watcher & timeline timestamp recorder
  useEffect(() => {
    if (!activeUid) {
      orderSnapshotRef.current = null;
      prevUidForSnapshotRef.current = null;
      return;
    }
    if (!ordersHydratedRef.current) return;

    const now = Date.now();
    setObservedStatusTimestamps((prev) => {
      let changed = false;
      const next = { ...prev };
      groupedOrders.forEach((grp) => {
        const derived = deriveGroupOrderStatus(grp);
        const curStatus = normalizeOrderStatus(derived.status);
        const existingMap = { ...(next[grp.groupKey] || {}) };
        let grpChanged = false;

        if (grp.statusTimestamps) {
          Object.entries(grp.statusTimestamps).forEach(([k, v]) => {
            if (Number.isFinite(v) && v > 0 && !existingMap[k]) {
              existingMap[k] = v;
              grpChanged = true;
            }
          });
        }
        if (!existingMap.PLACED && (grp.placedAt || grp.createdAt)) {
          existingMap.PLACED = Number(grp.placedAt || grp.createdAt);
          grpChanged = true;
        }
        if (!existingMap[curStatus]) {
          existingMap[curStatus] = now;
          grpChanged = true;
        }

        if (grpChanged) {
          next[grp.groupKey] = existingMap;
          changed = true;
        }
      });
      if (changed) {
        try {
          localStorage.setItem(TIMELINE_TS_STORAGE_KEY, JSON.stringify(next));
        } catch {
          // ignore storage quota
        }
      }
      return changed ? next : prev;
    });

    if (
      orderSnapshotRef.current === null ||
      prevUidForSnapshotRef.current !== activeUid
    ) {
      orderSnapshotRef.current = buildOrderSnapshotMap(groupedOrders);
      prevUidForSnapshotRef.current = activeUid;
      return;
    }

    const alerts = detectOrderNotificationEvents(
      orderSnapshotRef.current,
      groupedOrders
    );
    if (alerts.length > 0) {
      triggerHaptic('notification');
      alerts.forEach((n) => pushNotification(n, true));
    }
    orderSnapshotRef.current = buildOrderSnapshotMap(groupedOrders);
  }, [activeUid, groupedOrders, pushNotification]);

  // Cart actions
  const getItemQuantityInCart = useCallback(
    (itemId: string, storeId: string) => {
      const found = cartItems.find(
        (i) =>
          String(i.itemId) === String(itemId) &&
          (!storeId || String(i.storeId) === String(storeId))
      );
      return found ? found.qty : 0;
    },
    [cartItems]
  );

  const updateCartQtySafe = useCallback(
    (
      itemId: string,
      storeId: string,
      change: number,
      e?: React.MouseEvent
    ) => {
      if (e) e.stopPropagation();
      const storeData = stores[storeId];
      if (
        change > 0 &&
        (!storeData ||
          storeData.approved !== true ||
          storeData.suspended === true ||
          storeData.isOpen === false)
      ) {
        triggerHaptic('error');
        showToast(
          '🔴 Yeh store abhi offline/closed hai. Order nahi le raha!',
          'danger'
        );
        return;
      }
      const itemData = allMenus[storeId]?.[itemId];
      if (
        change > 0 &&
        (!itemData || itemData.available === false || itemData.adminApproved !== true)
      ) {
        triggerHaptic('error');
        showToast('Yeh product abhi sale ke liye available nahi hai.', 'danger');
        return;
      }

      if (change > 0) {
        triggerHaptic('cartAdd');
      } else if (change < 0) {
        triggerHaptic('cartRemove');
      }

      setCartItems((prev) => {
        const next = [...prev];
        const idx = next.findIndex(
          (i) =>
            String(i.itemId) === String(itemId) &&
            String(i.storeId) === String(storeId)
        );
        if (idx > -1) {
          const updatedQty = next[idx].qty + change;
          if (updatedQty <= 0) next.splice(idx, 1);
          else next[idx] = { ...next[idx], qty: updatedQty };
        } else if (change > 0 && itemData) {
          next.push({
            itemId: String(itemId),
            name: itemData.name || 'Grocery Item',
            price: Number(itemData.price || 0),
            qty: 1,
            imageUrl: itemData.imageUrl || '',
            storeId: String(storeId || ''),
            storeName: storeData?.name || 'Grocery Store',
          });
        }
        return next;
      });
    },
    [allMenus, showToast, stores]
  );

  const handleQuickAddStorePopular = useCallback(
    (storeId: string, item: MenuItem, e: React.MouseEvent) => {
      updateCartQtySafe(item.itemId, storeId, 1, e);
      const storeName = stores[storeId]?.name || item.storeName || 'store';
      showToast(
        `⚡ Added ${item.name} (₹${Number(item.price || 0).toFixed(0)}) from ${storeName}`,
        'success'
      );
    },
    [showToast, stores, updateCartQtySafe]
  );

  const handleReorderPastOrder = useCallback(
    (order: OrderRecord) => {
      const { nextCart, addedUnits, skippedCount } = mergePastOrderIntoCart(
        cartItems,
        order,
        stores,
        allMenus
      );

      if (addedUnits === 0) {
        triggerHaptic('error');
        showToast(
          'Sorry, items from this past order are currently unavailable.',
          'danger'
        );
        return;
      }

      triggerHaptic('cartAdd');
      setCartItems(nextCart);
      setIsCheckoutOpen(true);
      window.history.pushState({ modal: 'checkout' }, '');
      if (skippedCount > 0) {
        showToast(
          `🛒 Added ${addedUnits} item${addedUnits > 1 ? 's' : ''} (${skippedCount} unavailable skipped)`,
          'info'
        );
      } else {
        showToast(
          `🛒 Added ${addedUnits} item${addedUnits > 1 ? 's' : ''} to cart!`,
          'success'
        );
      }
    },
    [allMenus, cartItems, showToast, stores]
  );

  const toggleFavoriteItem = useCallback(
    (storeId: string, itemId: string, e?: React.MouseEvent) => {
      if (e) e.stopPropagation();
      if (!activeUid) return;
      const key = `${storeId}___${itemId}`;
      const currentlyFav = Boolean(customerProfile?.favorites?.[key]);
      triggerHaptic(currentlyFav ? 'tap' : 'favorite');

      if (isDemoMode) {
        setCustomerProfile((prev) => {
          const favs = { ...(prev?.favorites || {}) };
          if (currentlyFav) delete favs[key];
          else favs[key] = true;
          return { ...(prev || {}), favorites: favs };
        });
        showToast(
          currentlyFav ? 'Removed from Favorites' : '❤️ Added to Favorites!',
          'info'
        );
        return;
      }

      void set(
        ref(db, `customers/${activeUid}/favorites/${key}`),
        currentlyFav ? null : true
      ).then(() => {
        showToast(
          currentlyFav ? 'Removed from Favorites' : '❤️ Added to Favorites!',
          'info'
        );
      });
    },
    [activeUid, customerProfile?.favorites, isDemoMode, showToast]
  );

  // Voice search
  const startVoiceSearch = () => {
    const win = window as unknown as {
      SpeechRecognition?: new () => {
        lang: string;
        onresult: (ev: { results: Array<Array<{ transcript: string }>> }) => void;
        onerror: () => void;
        onend: () => void;
        start: () => void;
      };
      webkitSpeechRecognition?: new () => {
        lang: string;
        onresult: (ev: { results: Array<Array<{ transcript: string }>> }) => void;
        onerror: () => void;
        onend: () => void;
        start: () => void;
      };
    };
    const SR = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!SR) {
      showToast('Voice search supported on Chrome/Android.', 'info');
      return;
    }
    const rec = new SR();
    rec.lang = 'en-IN';
    setIsVoiceListening(true);
    rec.onresult = (ev) => {
      setSearchQuery(sanitizeText(ev.results[0][0].transcript));
      setIsVoiceListening(false);
    };
    rec.onerror = () => setIsVoiceListening(false);
    rec.onend = () => setIsVoiceListening(false);
    rec.start();
  };

  // GPS handlers
  const handleCheckoutGps = () => {
    if (!navigator.geolocation) {
      showToast('GPS unavailable.', 'danger');
      return;
    }
    setIsFetchingCheckoutGps(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = Number(pos.coords.latitude.toFixed(6));
        const lng = Number(pos.coords.longitude.toFixed(6));
        const link = `https://www.google.com/maps?q=${lat},${lng}`;
        setDetectedLat(lat);
        setDetectedLng(lng);
        setDetectedLocationLink(link);
        setIsFetchingCheckoutGps(false);
        try {
          const resp = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}&addressdetails=1`
          );
          const data = (await resp.json()) as {
            address?: {
              house_number?: string;
              road?: string;
              suburb?: string;
              village?: string;
              town?: string;
              city?: string;
            };
          };
          if (data?.address) {
            const addr = data.address;
            const area = addr.village || addr.town || addr.city || 'Gossaigaon';
            const built =
              [addr.house_number, addr.road || addr.suburb, area]
                .filter(Boolean)
                .join(', ') || 'Gossaigaon';
            setCustomerProfile((prev) => ({ ...(prev || {}), address: built }));
          }
        } catch {
          // Ignore reverse geocode failure
        }
        showToast('📍 Doorstep GPS Fixed!', 'success');
      },
      (err) => {
        setIsFetchingCheckoutGps(false);
        showToast('GPS Error: ' + err.message, 'danger');
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  };

  const handleProfileGps = () => {
    if (!navigator.geolocation) {
      showToast('GPS unavailable.', 'danger');
      return;
    }
    setIsDetectingProfileGps(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = Number(pos.coords.latitude.toFixed(6));
        const lng = Number(pos.coords.longitude.toFixed(6));
        const link = `https://www.google.com/maps?q=${lat},${lng}`;
        setDetectedLat(lat);
        setDetectedLng(lng);
        setDetectedLocationLink(link);
        setIsDetectingProfileGps(false);
        let newAddress = customerProfile?.address || 'Gossaigaon';
        try {
          const resp = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}&addressdetails=1`
          );
          const data = (await resp.json()) as {
            address?: {
              road?: string;
              town?: string;
              city?: string;
              village?: string;
            };
          };
          if (data?.address) {
            const town =
              data.address.town ||
              data.address.city ||
              data.address.village ||
              'Gossaigaon';
            newAddress = `${data.address.road ? data.address.road + ', ' : ''}${town}`;
          }
        } catch {
          // Ignore
        }
        setCustomerProfile((prev) => ({
          ...(prev || {}),
          lat,
          lng,
          locationLink: link,
          address: newAddress,
        }));
        if (currentUser) {
          void update(ref(db, `customers/${currentUser.uid}`), {
            lat,
            lng,
            locationLink: link,
            address: newAddress,
            updatedAt: Date.now(),
          });
        }
        showToast('📍 Exact Profile GPS Saved!', 'success');
      },
      (err) => {
        setIsDetectingProfileGps(false);
        showToast('GPS Error: ' + err.message, 'danger');
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  };

  // Profile Save
  const handleSaveProfile = (nameRaw: string, phoneRaw: string, addressRaw: string) => {
    const name = sanitizeInputBounded(nameRaw, 80);
    const phone = phoneRaw.replace(/\D/g, '').slice(0, 10);
    const address = sanitizeInputBounded(addressRaw, 220);
    if (name.length < 2) {
      showToast('Enter your full name!', 'danger');
      return;
    }
    if (!isValidIndianMobile(phone)) {
      showToast('Enter valid 10-digit mobile number!', 'danger');
      return;
    }
    const updates: Partial<CustomerProfile> = {
      name,
      phone,
      address,
      updatedAt: Date.now(),
    };
    if (detectedLat && detectedLng) {
      updates.lat = detectedLat;
      updates.lng = detectedLng;
      updates.locationLink = detectedLocationLink;
    }

    if (isDemoMode) {
      setCustomerProfile((prev) => ({ ...(prev || {}), ...updates }));
      showToast('Profile saved!', 'success');
      return;
    }

    if (currentUser) {
      void update(ref(db, `customers/${currentUser.uid}`), updates).then(() =>
        showToast('Profile saved!', 'success')
      );
    }
  };

  // Place Order
  const handlePlaceOrder = async (payload: {
    address: string;
    phone: string;
    paymentMode: 'COD' | 'UPI' | 'WALLET';
    utr: string;
    screenshotData: string;
    appliedDiscount: number;
    appliedCouponCode: string;
  }) => {
    if (isPlacingOrder || !activeUid) return;
    if (maintenanceMode) {
      triggerHaptic('error');
      showToast(`🚧 ${maintenanceMessage}`, 'danger');
      return;
    }
    if (cartItems.length === 0) {
      triggerHaptic('error');
      setIsCheckoutOpen(false);
      showToast('Cart is empty!', 'danger');
      return;
    }

    // Reconcile client cart against live catalog prices to block price tampering
    const {
      safeCart: verifiedCartItems,
      tamperedCount,
      removedCount,
    } = reconcileCartWithCatalog(cartItems, stores, allMenus);
    if (tamperedCount > 0 || removedCount > 0) {
      triggerHaptic('error');
      setCartItems(verifiedCartItems);
      showToast(
        '🛡️ Item availability or prices changed—your basket has been synced. Please review and place order again.',
        'danger'
      );
      return;
    }

    for (const item of verifiedCartItems) {
      const st = stores[item.storeId];
      if (!st || st.approved !== true || st.suspended === true || st.isOpen === false) {
        triggerHaptic('error');
        showToast(
          `🔴 "${item.storeName}" abhi closed hai! Checkout se closed store ke items hatayein.`,
          'danger'
        );
        return;
      }
      const menuProd = allMenus[item.storeId]?.[item.itemId];
      if (!menuProd || menuProd.available === false || menuProd.adminApproved !== true) {
        triggerHaptic('error');
        showToast(`⚠️ "${item.name}" abhi available nahi hai.`, 'danger');
        return;
      }
    }

    const subtotalCheck = verifiedCartItems.reduce(
      (acc, curr) => acc + curr.price * curr.qty,
      0
    );
    if (minOrderAmount > 0 && subtotalCheck < minOrderAmount) {
      triggerHaptic('error');
      showToast(`Minimum order ₹${minOrderAmount} hai!`, 'danger');
      return;
    }

    const address = sanitizeInputBounded(payload.address, 220);
    const phone = payload.phone.replace(/\D/g, '').slice(0, 10);
    const utr = payload.utr.replace(/\D/g, '').slice(0, 12);

    if (address.length < 6) {
      triggerHaptic('error');
      showToast('Poora delivery address enter karein!', 'danger');
      return;
    }
    if (!isValidIndianMobile(phone)) {
      triggerHaptic('error');
      showToast('Valid 10-digit mobile number enter karein!', 'danger');
      return;
    }
    if (payload.paymentMode === 'UPI') {
      const knownUtrs = collectKnownUtrs(cachedOrders, localUsedUtrs);
      const utrCheck = validateUpiUtr(utr, knownUtrs);
      if (!utrCheck.valid) {
        triggerHaptic('error');
        showToast(
          utrCheck.reason || 'Enter a valid 12-digit UPI UTR number!',
          'danger'
        );
        return;
      }
    }

    // Group & calculate net payable using catalog-verified prices
    const storeBatches: Record<
      string,
      { storeName: string; items: CartItem[]; subtotal: number }
    > = {};
    let totalItemsSubtotal = 0;
    verifiedCartItems.forEach((item) => {
      const sId = item.storeId || 'general';
      if (!storeBatches[sId]) {
        storeBatches[sId] = {
          storeName: item.storeName || 'Store',
          items: [],
          subtotal: 0,
        };
      }
      storeBatches[sId].items.push(item);
      storeBatches[sId].subtotal += item.price * item.qty;
      totalItemsSubtotal += item.price * item.qty;
    });

    let totalStoreDiscount = 0;
    Object.entries(storeBatches).forEach(([sId, batch]) => {
      const st = stores[sId];
      if (!st) return;
      const pct = Number(st.storeDiscountPercent || 0);
      const minOrd = Number(st.storeDiscountMinOrder || 0);
      if (pct > 0 && batch.subtotal >= minOrd) {
        totalStoreDiscount += Math.round((batch.subtotal * pct) / 100);
      }
    });

    const isFreeDelivery = totalItemsSubtotal >= freeDeliveryMinOrder;
    const delCharge = isFreeDelivery ? 0 : baseDeliveryCharge;
    const activeHandling = handlingFee > 0 ? handlingFee : 0;
    const netPayableTotal = Math.max(
      1,
      totalItemsSubtotal +
        delCharge +
        activeHandling -
        totalStoreDiscount -
        payload.appliedDiscount
    );

    if (payload.paymentMode === 'WALLET') {
      const curBal = Number(customerProfile?.walletBalance || 0);
      if (curBal < netPayableTotal) {
        triggerHaptic('error');
        showToast(
          `Insufficient Wallet balance (Need ₹${netPayableTotal.toFixed(0)})!`,
          'danger'
        );
        return;
      }
    }

    const spamCheck = evaluateSpamRisk(
      cachedOrders,
      netPayableTotal,
      payload.paymentMode
    );
    if (spamCheck.block && spamCheck.reason) {
      triggerHaptic('error');
      showToast(spamCheck.reason, 'danger');
      return;
    }

    setIsPlacingOrder(true);

    try {
      const storeCount = Object.keys(storeBatches).length;
      const deliveryOtp = Math.floor(1000 + Math.random() * 9000).toString();
      const accurateLocationLink =
        detectedLat && detectedLng
          ? `https://www.google.com/maps?q=${detectedLat},${detectedLng}`
          : '';
      const batchGroupId = 'COMBO_' + Date.now();

      if (isDemoMode) {
        const newOrders: Record<string, Omit<OrderRecord, 'orderId'>> = {};
        let isFirstStore = true;
        Object.entries(storeBatches).forEach(([sId, batch], idx) => {
          const currentStore = stores[sId] || {};
          const assignedRiderUid = findNearestAvailableRider(
            deliveryPartners,
            currentStore.lat,
            currentStore.lng
          );
          const assignedRiderObj = assignedRiderUid
            ? deliveryPartners[assignedRiderUid]
            : null;
          const isFirst = isFirstStore;
          const batchDeliveryCharge = isFreeDelivery
            ? 0
            : isFirst
              ? baseDeliveryCharge
              : 0;
          const batchHandlingFee =
            handlingFee > 0 && isFirst ? handlingFee : 0;
          const batchCouponDiscount =
            payload.appliedDiscount > 0 && isFirst ? payload.appliedDiscount : 0;
          const pct = Number(currentStore.storeDiscountPercent || 0);
          const minOrd = Number(currentStore.storeDiscountMinOrder || 0);
          const batchStoreDiscount =
            pct > 0 && batch.subtotal >= minOrd
              ? Math.round((batch.subtotal * pct) / 100)
              : 0;
          isFirstStore = false;

          const batchTotal = Math.max(
            1,
            batch.subtotal +
              batchDeliveryCharge +
              batchHandlingFee -
              batchStoreDiscount -
              batchCouponDiscount
          );

          newOrders[`ord_${Date.now()}_${idx}`] = {
            batchGroupId,
            customerUid: activeUid,
            restaurantId: sId,
            deliveryUid: assignedRiderUid || null,
            riderLat: assignedRiderObj?.lat || null,
            riderLng: assignedRiderObj?.lng || null,
            assignedAt: assignedRiderUid ? Date.now() : null,
            items: batch.items,
            subtotalAmount: Number(batch.subtotal.toFixed(2)),
            deliveryCharge: Number(batchDeliveryCharge.toFixed(2)),
            handlingFee: Number(batchHandlingFee.toFixed(2)),
            storeDiscountAmount: Number(batchStoreDiscount.toFixed(2)),
            discountAmount: Number(batchCouponDiscount.toFixed(2)),
            couponCode: payload.appliedCouponCode || '',
            totalAmount: Number(batchTotal.toFixed(2)),
            address,
            phone,
            customerLat: detectedLat || null,
            customerLng: detectedLng || null,
            locationLink: accurateLocationLink,
            deliveryOtp,
            status: 'PLACED',
            paymentMode: payload.paymentMode,
            paymentStatus:
              payload.paymentMode === 'UPI'
                ? 'PENDING_VERIFICATION'
                : payload.paymentMode === 'WALLET'
                  ? 'VERIFIED'
                  : 'COD',
            transactionId: payload.paymentMode === 'UPI' ? utr : '',
            paymentScreenshot:
              payload.paymentMode === 'UPI' ? payload.screenshotData || '' : '',
            placedAt: Date.now(),
            statusTimestamps: { PLACED: Date.now() },
            createdAt: Date.now(),
            updatedAt: Date.now(),
          };
        });

        if (payload.paymentMode === 'WALLET') {
          setCustomerProfile((prev) => ({
            ...(prev || {}),
            walletBalance: Math.max(
              0,
              Number(prev?.walletBalance || 0) - netPayableTotal
            ),
          }));
          setWalletTransactions((prev) => ({
            ...prev,
            [`tx_${Date.now()}`]: {
              type: 'DEBIT',
              amount: Number(netPayableTotal.toFixed(2)),
              note: 'Paid for grocery order',
              createdAt: Date.now(),
            },
          }));
        }

        const createdOrderIds = Object.keys(newOrders);
        setCachedOrders((prev) => ({ ...newOrders, ...prev }));
        if (payload.paymentMode === 'UPI') {
          recordUsedUtr(utr);
        }
        setCartItems([]);
        setIsCheckoutOpen(false);
        setMenuStoreId(null);
        switchNav('orders');
        triggerHaptic('success');

        const stageTransitions: Array<{ delayMs: number; nextStatus: string }> = [
          { delayMs: 2800, nextStatus: 'PREPARING' },
          { delayMs: 5600, nextStatus: 'PACKING' },
          { delayMs: 8400, nextStatus: 'OUT_FOR_DELIVERY' },
        ];
        stageTransitions.forEach(({ delayMs, nextStatus }) => {
          const timerId = setTimeout(() => {
            const transitionTs = Date.now();
            setCachedOrders((prev) => {
              let changed = false;
              const updated = { ...prev };
              createdOrderIds.forEach((id) => {
                const cur = updated[id];
                if (cur && cur.status !== 'CANCELLED' && cur.status !== 'DELIVERED') {
                  updated[id] = {
                    ...cur,
                    status: nextStatus,
                    statusTimestamps: {
                      ...(cur.statusTimestamps || {}),
                      [nextStatus]: transitionTs,
                    },
                    updatedAt: transitionTs,
                  };
                  changed = true;
                }
              });
              return changed ? updated : prev;
            });
          }, delayMs);
          demoProgressTimersRef.current.push(timerId);
        });

        pushNotification(
          {
            id: `placed_${batchGroupId}`,
            title: `🛍️ Order Placed! PIN: ${deliveryOtp}`,
            body: `Your order from ${storeCount} store${storeCount > 1 ? 's' : ''} is placed for 15-min delivery.`,
            tag: `gb-order-${batchGroupId}`,
            type: 'ORDER',
            targetTab: 'orders',
            createdAt: Date.now(),
            read: false,
          },
          true
        );
        return;
      }

      if (payload.paymentMode === 'WALLET') {
        const txResult = await runTransaction(
          ref(db, `customers/${activeUid}/walletBalance`),
          (bal) => {
            const cur = Number(bal || 0);
            if (cur < netPayableTotal) return;
            return Number((cur - netPayableTotal).toFixed(2));
          }
        );
        if (!txResult.committed) {
          triggerHaptic('error');
          showToast('Insufficient Wallet balance!', 'danger');
          return;
        }
        await push(ref(db, `walletTransactions/${activeUid}`), {
          type: 'DEBIT',
          amount: Number(netPayableTotal.toFixed(2)),
          note: 'Paid for grocery order',
          createdAt: Date.now(),
        });
      }

      const orderPromises: Array<PromiseLike<unknown>> = [];
      let isFirstStore = true;

      Object.entries(storeBatches).forEach(([sId, batch]) => {
        const currentStore = stores[sId] || {};
        const assignedRiderUid = findNearestAvailableRider(
          deliveryPartners,
          currentStore.lat,
          currentStore.lng
        );
        const assignedRiderObj = assignedRiderUid
          ? deliveryPartners[assignedRiderUid]
          : null;
        const isFirst = isFirstStore;
        const batchDeliveryCharge = isFreeDelivery
          ? 0
          : isFirst
            ? baseDeliveryCharge
            : 0;
        const batchHandlingFee =
          handlingFee > 0 && isFirst ? handlingFee : 0;
        const batchCouponDiscount =
          payload.appliedDiscount > 0 && isFirst ? payload.appliedDiscount : 0;
        const pct = Number(currentStore.storeDiscountPercent || 0);
        const minOrd = Number(currentStore.storeDiscountMinOrder || 0);
        const batchStoreDiscount =
          pct > 0 && batch.subtotal >= minOrd
            ? Math.round((batch.subtotal * pct) / 100)
            : 0;
        isFirstStore = false;

        const batchTotal = Math.max(
          1,
          batch.subtotal +
            batchDeliveryCharge +
            batchHandlingFee -
            batchStoreDiscount -
            batchCouponDiscount
        );

        const orderData = {
          batchGroupId,
          customerUid: activeUid,
          restaurantId: sId,
          deliveryUid: assignedRiderUid || null,
          riderLat: assignedRiderObj?.lat || null,
          riderLng: assignedRiderObj?.lng || null,
          assignedAt: assignedRiderUid ? Date.now() : null,
          items: batch.items,
          subtotalAmount: Number(batch.subtotal.toFixed(2)),
          deliveryCharge: Number(batchDeliveryCharge.toFixed(2)),
          handlingFee: Number(batchHandlingFee.toFixed(2)),
          storeDiscountAmount: Number(batchStoreDiscount.toFixed(2)),
          discountAmount: Number(batchCouponDiscount.toFixed(2)),
          couponCode: payload.appliedCouponCode || '',
          totalAmount: Number(batchTotal.toFixed(2)),
          address,
          phone,
          customerLat: detectedLat || null,
          customerLng: detectedLng || null,
          locationLink: accurateLocationLink,
          deliveryOtp,
          status: 'PLACED',
          paymentMode: payload.paymentMode,
          paymentStatus:
            payload.paymentMode === 'UPI'
              ? 'PENDING_VERIFICATION'
              : payload.paymentMode === 'WALLET'
                ? 'VERIFIED'
                : 'COD',
          transactionId: payload.paymentMode === 'UPI' ? utr : '',
          paymentScreenshot:
            payload.paymentMode === 'UPI' ? payload.screenshotData || '' : '',
          isSpamSuspect: spamCheck.isSpamSuspect || false,
          spamReason: spamCheck.spamReason || '',
          placedAt: Date.now(),
          statusTimestamps: { PLACED: Date.now() },
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };
        orderPromises.push(push(ref(db, 'orders'), orderData));
      });

      await Promise.all(orderPromises);
      if (payload.paymentMode === 'UPI') {
        recordUsedUtr(utr);
      }
      if (spamCheck.isSpamSuspect) {
        void runTransaction(
          ref(db, `customers/${activeUid}/spamScore`),
          (s) => Number(s || 0) + 1
        );
      }

      setCartItems([]);
      setIsCheckoutOpen(false);
      setMenuStoreId(null);
      switchNav('orders');
      triggerHaptic('success');
      pushNotification(
        {
          id: `placed_${batchGroupId}`,
          title: `🛍️ Order Placed! PIN: ${deliveryOtp}`,
          body: `Your order from ${storeCount} store${storeCount > 1 ? 's' : ''} is placed for 15-min delivery.`,
          tag: `gb-order-${batchGroupId}`,
          type: 'ORDER',
          targetTab: 'orders',
          createdAt: Date.now(),
          read: false,
        },
        true
      );
    } catch (err) {
      triggerHaptic('error');
      showToast(
        'Error: ' + (err instanceof Error ? err.message : 'Order failed'),
        'danger'
      );
    } finally {
      setIsPlacingOrder(false);
    }
  };

  // Wallet Deposit / Withdraw
  const handleWalletDepositSubmit = async (
    amt: number,
    utrRaw: string,
    screenshotData: string
  ) => {
    const cleanAmt = Number(amt);
    if (!Number.isFinite(cleanAmt) || cleanAmt < minCustomerDeposit || cleanAmt > maxCustomerDeposit) {
      showToast(
        `Deposit limit: ₹${minCustomerDeposit} to ₹${maxCustomerDeposit}!`,
        'danger'
      );
      return;
    }
    const cleanUtr = utrRaw.replace(/\D/g, '').slice(0, 12);
    const knownUtrs = collectKnownUtrs(cachedOrders, localUsedUtrs);
    const utrCheck = validateUpiUtr(cleanUtr, knownUtrs);
    if (!utrCheck.valid) {
      showToast(utrCheck.reason || 'Enter valid 12-digit UTR number!', 'danger');
      return;
    }
    if (isDemoMode) {
      recordUsedUtr(cleanUtr);
      setIsDepositOpen(false);
      showToast('✅ Deposit request sent to Admin for verification!', 'success');
      return;
    }
    if (!activeUid) return;
    await push(ref(db, 'walletRequests'), {
      type: 'DEPOSIT',
      customerUid: activeUid,
      customerName: customerProfile?.name || 'Customer',
      customerPhone: customerProfile?.phone || '',
      amount: cleanAmt,
      utr: cleanUtr,
      screenshot: screenshotData || '',
      status: 'PENDING',
      createdAt: Date.now(),
    });
    recordUsedUtr(cleanUtr);
    setIsDepositOpen(false);
    showToast('✅ Deposit request sent to Admin for verification!', 'success');
  };

  const handleWalletWithdrawSubmit = async (amt: number, upiIdRaw: string) => {
    const bal = Number(customerProfile?.walletBalance || 0);
    const upiId = sanitizeInputBounded(upiIdRaw, 80);
    const safety = evaluateWalletWithdrawalSafety({
      amount: Number(amt),
      balance: bal,
      minWithdraw: minCustomerWithdraw,
      maxWithdraw: maxCustomerWithdraw,
      upiId,
      lastWithdrawAt: lastWithdrawAtRef.current,
    });
    if (!safety.allowed) {
      showToast(safety.reason || 'Invalid withdrawal request!', 'danger');
      return;
    }

    if (isDemoMode) {
      lastWithdrawAtRef.current = Date.now();
      setCustomerProfile((prev) => ({
        ...(prev || {}),
        walletBalance: Math.max(0, bal - amt),
      }));
      setWalletTransactions((prev) => ({
        ...prev,
        [`tx_wd_${Date.now()}`]: {
          type: 'DEBIT',
          amount: amt,
          note: `Withdrawal requested to ${upiId}`,
          createdAt: Date.now(),
        },
      }));
      setIsWithdrawOpen(false);
      showToast('✅ Withdrawal request submitted to Admin!', 'success');
      return;
    }
    if (!activeUid) return;
    const txRes = await runTransaction(
      ref(db, `customers/${activeUid}/walletBalance`),
      (b) => {
        const cur = Number(b || 0);
        if (cur < amt) return;
        return Math.max(0, cur - amt);
      }
    );
    if (!txRes.committed) {
      showToast('Insufficient wallet balance!', 'danger');
      return;
    }
    lastWithdrawAtRef.current = Date.now();
    await push(ref(db, `walletTransactions/${activeUid}`), {
      type: 'DEBIT',
      amount: amt,
      note: `Withdrawal requested to ${upiId}`,
      createdAt: Date.now(),
    });
    await push(ref(db, 'walletRequests'), {
      type: 'WITHDRAW',
      customerUid: activeUid,
      customerName: customerProfile?.name || 'Customer',
      customerPhone: customerProfile?.phone || '',
      amount: amt,
      upiId,
      status: 'PENDING',
      createdAt: Date.now(),
    });
    setIsWithdrawOpen(false);
    showToast('✅ Withdrawal request submitted to Admin!', 'success');
  };

  // Ratings & Reviews
  const handleSubmitRiderRating = async (
    group: ReturnType<typeof groupCustomerOrders>[number],
    stars: number,
    comment: string
  ) => {
    if (!group.deliveryUid || !activeUid) return;
    const cleanComment = sanitizeInputBounded(comment, 240);
    if (isDemoMode) {
      setRatingModalState(null);
      showToast('⭐ Thank you for rating the rider!', 'success');
      return;
    }
    const riderUid = group.deliveryUid;
    const riderSnap = await get(ref(db, `deliveryPartners/${riderUid}`));
    const rData = (riderSnap.val() || {}) as DeliveryPartner;
    const prevCount = Number(rData.ratingCount || 0);
    const prevAvg = Number(rData.ratingAvg || 5);
    const newCount = prevCount + 1;
    const newAvg = Number(
      (((prevAvg * prevCount) + stars) / newCount).toFixed(2)
    );

    await update(ref(db, `deliveryPartners/${riderUid}`), {
      ratingAvg: newAvg,
      ratingCount: newCount,
    });
    await push(ref(db, `riderRatings/${riderUid}`), {
      orderGroup: group.groupKey,
      customerUid: activeUid,
      customerName: customerProfile?.name || 'Customer',
      rating: stars,
      comment: cleanComment,
      createdAt: Date.now(),
    });
    await Promise.all(
      group.orders.map((o) =>
        update(ref(db, `orders/${o.orderId}`), {
          riderRating: stars,
          riderReview: cleanComment,
          riderRatedAt: Date.now(),
        })
      )
    );
    setRatingModalState(null);
    showToast('⭐ Thank you for rating the rider!', 'success');
  };

  const handleSubmitProductReviews = async (
    group: ReturnType<typeof groupCustomerOrders>[number],
    reviewsInput: Record<string, { rating: number; review: string }>
  ) => {
    if (!activeUid) return;
    if (isDemoMode) {
      setRatingModalState(null);
      showToast('🎉 Product reviews published!', 'success');
      return;
    }
    for (let oIdx = 0; oIdx < group.orders.length; oIdx++) {
      const o = group.orders[oIdx];
      const raw = Array.isArray(o.items) ? o.items : Object.values(o.items || {});
      for (let iIdx = 0; iIdx < raw.length; iIdx++) {
        const item = raw[iIdx];
        const uidKey = `${oIdx}_${iIdx}`;
        const entry = reviewsInput[uidKey] || { rating: 5, review: '' };
        const rating = Math.min(5, Math.max(1, Number(entry.rating || 5)));
        const review = sanitizeInputBounded(entry.review, 240);
        const sId = item.storeId || o.restaurantId;
        const iId = item.itemId;
        if (sId && iId) {
          await set(
            ref(db, `productReviews/${sId}/${iId}/${o.orderId}_${activeUid}`),
            {
              customerName: customerProfile?.name || 'Verified Buyer',
              rating,
              review,
              createdAt: Date.now(),
            }
          );
          const mSnap = await get(ref(db, `menus/${sId}/${iId}`));
          if (mSnap.exists()) {
            const mData = mSnap.val() as MenuItem;
            const prevC = Number(mData.ratingCount || 0);
            const prevA = Number(mData.ratingAvg || 5);
            const nC = prevC + 1;
            const nA = Number((((prevA * prevC) + rating) / nC).toFixed(2));
            await update(ref(db, `menus/${sId}/${iId}`), {
              ratingAvg: nA,
              ratingCount: nC,
            });
          }
        }
      }
      await update(ref(db, `orders/${o.orderId}`), { productsReviewed: true });
    }
    setRatingModalState(null);
    showToast('🎉 Product reviews published!', 'success');
  };

  // Feedback & Cancel
  const handleFeedbackSubmit = async (
    subject: string,
    rating: number,
    message: string
  ) => {
    if (!activeUid) return;
    const item: FeedbackItem = {
      role: 'CUSTOMER',
      uid: activeUid,
      name: customerProfile?.name || 'Customer',
      phone: customerProfile?.phone || '',
      subject: sanitizeInputBounded(subject, 120),
      rating: Math.min(5, Math.max(1, Number(rating || 5))),
      message: sanitizeInputBounded(message, 600),
      status: 'OPEN',
      createdAt: Date.now(),
    };
    if (isDemoMode) {
      setMyFeedbacks((prev) => ({ [`fb_${Date.now()}`]: item, ...prev }));
      setIsFeedbackOpen(false);
      showToast('💬 Feedback sent to Admin Helpline!', 'success');
      return;
    }
    await push(ref(db, 'feedbacks'), item);
    setIsFeedbackOpen(false);
    showToast('💬 Feedback sent to Admin Helpline!', 'success');
  };

  const handleConfirmCancelOrder = async (groupKey: string, reason: string) => {
    const targetGroup = groupedOrders.find((g) => g.groupKey === groupKey);
    if (!targetGroup) return;
    if (isDemoMode) {
      setCachedOrders((prev) => {
        const next = { ...prev };
        targetGroup.orders.forEach((o) => {
          if (next[o.orderId]) {
            next[o.orderId] = { ...next[o.orderId], status: 'CANCELLED' };
          }
        });
        return next;
      });
      setCancelGroupKey(null);
      triggerHaptic('warning');
      showToast('Order Cancelled', 'info');
      return;
    }
    await Promise.all(
      targetGroup.orders.map((o) =>
        update(ref(db, `orders/${o.orderId}`), {
          status: 'CANCELLED',
          cancelledBy: 'CUSTOMER',
          cancelReason: reason,
          updatedAt: Date.now(),
        })
      )
    );
    setCancelGroupKey(null);
    triggerHaptic('warning');
    showToast('Order Cancelled', 'info');
  };

  const handleLogout = () => {
    setCartItems([]);
    try {
      localStorage.removeItem(CART_STORAGE_KEY);
    } catch {
      // Ignore
    }
    if (currentUser) {
      void signOut(auth);
    }
  };

  const handleCheckEmailVerified = async () => {
    const targetUser = auth.currentUser || currentUser;
    if (!targetUser) return;
    setVerifyStatusMsg('');
    setVerifyStatusErr('');
    setIsCheckingVerification(true);
    try {
      await targetUser.reload();
      setAuthVerifyTick((t) => t + 1);
      if (auth.currentUser?.emailVerified) {
        triggerHaptic('success');
        showToast('✅ Email verified! Welcome to Gossaigaon Bazar.', 'success');
      } else {
        triggerHaptic('error');
        setVerifyStatusErr(
          'Email is not verified yet. Open the link in your inbox or spam folder first.'
        );
      }
    } catch (err) {
      triggerHaptic('error');
      setVerifyStatusErr(mapAuthErrorSafe(err, 'verification'));
    } finally {
      setIsCheckingVerification(false);
    }
  };

  const handleResendVerificationEmail = async () => {
    const targetUser = auth.currentUser || currentUser;
    if (!targetUser || verifyResendCooldownSec > 0) return;
    setVerifyStatusMsg('');
    setVerifyStatusErr('');
    setIsResendingVerification(true);
    try {
      await sendEmailVerification(targetUser);
      triggerHaptic('success');
      setVerifyResendCooldownSec(60);
      setVerifyStatusMsg(
        `Fresh verification link sent to ${targetUser.email || 'your inbox'}.`
      );
      showToast('📧 Verification link sent again!', 'success');
    } catch (err) {
      triggerHaptic('error');
      setVerifyStatusErr(mapAuthErrorSafe(err, 'verification'));
    } finally {
      setIsResendingVerification(false);
    }
  };

  const handleEnablePush = async () => {
    const res = await enablePushNotifications();
    showToast(res.message, res.granted ? 'success' : 'info');
  };

  const handleSendTestPush = async () => {
    const res = await sendTestPush();
    showToast(res.message, res.granted ? 'success' : 'info');
  };

  const handleSendPasswordReset = async () => {
    const targetEmail = currentUser?.email || customerProfile?.email || '';
    if (!targetEmail) {
      showToast('No verified account email found for reset.', 'danger');
      return;
    }
    if (isDemoMode) {
      showToast(`📧 Password reset link prepared for ${targetEmail}`, 'success');
      return;
    }
    try {
      await sendPasswordResetEmail(auth, targetEmail);
      showToast(`📧 Password reset link sent to ${targetEmail}`, 'success');
    } catch {
      showToast('Could not send reset email right now. Try again shortly.', 'danger');
    }
  };

  const favCount = Object.keys(customerProfile?.favorites || {}).length;
  const totalCartCount = cartItems.reduce((acc, curr) => acc + curr.qty, 0);
  const totalCartSubtotal = cartItems.reduce(
    (acc, curr) => acc + curr.price * curr.qty,
    0
  );
  const referralCode =
    customerProfile?.referralCode ||
    (activeUid ? 'GB' + activeUid.slice(0, 6).toUpperCase() : 'GBUSER');

  const activeRatingGroup = ratingModalState
    ? groupedOrders.find((g) => g.groupKey === ratingModalState.groupKey) || null
    : null;

  return (
    <>
      <LivePushBanner
        notification={activeBanner}
        onDismiss={dismissBanner}
        onOpen={(notif) => {
          dismissBanner();
          markNotificationRead(notif.id);
          if (notif.targetTab) {
            switchNav(notif.targetTab);
          }
        }}
      />

      <div id="toast-container">
        {toasts.map((t) => (
          <div key={t.id} className={`toast ${t.type}`}>
            <span>{t.msg}</span>
          </div>
        ))}
      </div>

      {customerProfile?.blocked === true && (
        <div id="banned-screen">
          <i
            className="fa-solid fa-ban"
            style={{
              fontSize: '3.5rem',
              color: 'var(--danger)',
              marginBottom: '1rem',
            }}
          />
          <h2 style={{ fontWeight: 900, marginBottom: '0.5rem' }}>
            Account Suspended
          </h2>
          <p
            style={{
              color: '#94a3b8',
              fontSize: '0.85rem',
              marginBottom: '1.5rem',
            }}
          >
            Your account is suspended due to invalid or spam activities. Contact
            support.
          </p>
          <button
            type="button"
            className="btn btn-outline"
            style={{ color: '#fff', borderColor: '#fff' }}
            onClick={handleLogout}
          >
            Sign Out
          </button>
        </div>
      )}

      <div className="app-viewport">
        {gmpQuotaExceeded && (
          <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
            <span>
              Google Maps Platform quota reached. If you are the app owner, visit{' '}
              <a
                href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
                target="_blank"
                rel="noopener noreferrer"
                className="underline font-semibold text-amber-950 hover:text-amber-800"
              >
                maps developer site
              </a>{' '}
              for instructions to update your account.
            </span>
          </div>
        )}

        <OfflineIndicator />

        {settings.announcementActive && settings.announcementText && (
          <div id="announcement-ticker">{settings.announcementText}</div>
        )}

        {maintenanceMode && (
          <div id="maintenance-banner">🚧 {maintenanceMessage}</div>
        )}

        {authReady && !isLoggedIn && (
          <AuthScreen
            brandName={settings.appBrandName || 'Gossaigaon Bazar'}
            allowReferrals={allowReferrals}
            referrerBonus={referrerBonus}
            refereeBonus={refereeBonus}
            showToast={showToast}
            onDetectedGps={(lat, lng, link) => {
              setDetectedLat(lat);
              setDetectedLng(lng);
              setDetectedLocationLink(link);
            }}
            detectedLat={detectedLat}
            detectedLng={detectedLng}
            detectedLocationLink={detectedLocationLink}
          />
        )}

        {authReady && currentUser && needsEmailVerification && (
          <EmailVerificationScreen
            brandName={settings.appBrandName || 'Gossaigaon Bazar'}
            userEmail={activeUserSnapshot?.email || ''}
            isChecking={isCheckingVerification}
            isResending={isResendingVerification}
            resendCooldownSec={verifyResendCooldownSec}
            statusMessage={verifyStatusMsg}
            statusError={verifyStatusErr}
            onCheckVerified={() => void handleCheckEmailVerified()}
            onResendVerification={() => void handleResendVerificationEmail()}
            onLogout={handleLogout}
          />
        )}

        {/* HEADER */}
        <header className="app-header">
          <div className="header-top-row">
            <div style={{ minWidth: 0 }}>
              <div className="express-delivery-badge">
                <span id="header-eta-text">
                  {settings.expressEtaText || '⚡ 15 MINS EXPRESS'}
                </span>
                <span className="express-pill" id="header-local-badge">
                  {settings.expressLocalBadge || 'LOCAL'}
                </span>
              </div>
              <button
                type="button"
                className="delivery-location-pill"
                onClick={() => switchNav('profile')}
              >
                <strong id="header-address-text">
                  {customerProfile?.address
                    ? customerProfile.address.split(',')[0].slice(0, 24)
                    : 'Gossaigaon Town'}
                </strong>
                <i
                  className="fa-solid fa-chevron-down"
                  style={{ fontSize: '0.75rem', color: '#64748b' }}
                />
              </button>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexShrink: 0 }}>
              <button
                type="button"
                className="header-icon-btn"
                aria-label="My Favorites"
                onClick={() => {
                  triggerHaptic('tap');
                  setCurrentCategoryFilter('FAVORITES');
                  switchNav('home');
                }}
                title="My Favorites"
              >
                <i
                  className="fa-solid fa-heart"
                  style={{ color: 'var(--danger)' }}
                />
                {favCount > 0 && (
                  <span className="fav-dot-count" id="header-fav-count">
                    {favCount}
                  </span>
                )}
              </button>
              <button
                type="button"
                className="header-icon-btn"
                aria-label="Push Notifications"
                onClick={() => {
                  triggerHaptic('tap');
                  setIsInboxOpen(true);
                  window.history.pushState({ modal: 'inbox' }, '');
                }}
                title="Notifications"
              >
                <i
                  className="fa-solid fa-bell"
                  style={{
                    color:
                      pushPermission === 'granted'
                        ? 'var(--brand-green)'
                        : '#475569',
                  }}
                />
                {unreadCount > 0 && (
                  <span className="fav-dot-count">{unreadCount}</span>
                )}
              </button>
              <button
                type="button"
                className="header-icon-btn"
                aria-label="My Wallet"
                onClick={() => switchNav('wallet', true, true)}
                title="My Wallet"
              >
                <i
                  className="fa-solid fa-wallet"
                  style={{ color: 'var(--brand-green)' }}
                />
              </button>
              <button
                type="button"
                className="header-icon-btn"
                aria-label="My Profile"
                onClick={() => switchNav('profile', true, true)}
                title="My Profile"
              >
                <i className="fa-solid fa-user" />
              </button>
            </div>
          </div>

          <div className="quick-search-wrap">
            <i className="fa-solid fa-magnifying-glass" />
            <input
              type="text"
              id="store-search-input"
              className="quick-search-input"
              aria-label="Search groceries and stores"
              placeholder={
                settings.searchPlaceholder ||
                'Search vegetables, atta, milk, oil across stores...'
              }
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            {allowVoiceSearch && (
              <button
                type="button"
                className={`voice-mic-btn ${isVoiceListening ? 'listening' : ''}`}
                id="voice-btn"
                aria-label="Voice Search"
                onClick={startVoiceSearch}
                title="Voice Search"
              >
                <i className="fa-solid fa-microphone" />
              </button>
            )}
          </div>
        </header>

        {/* DYNAMIC CATEGORY STRIP */}
        <div className="categories-circular-strip" id="categories-strip">
          {categories.map((cat) => {
            const isActive = currentCategoryFilter === cat.id;
            return (
              <button
                type="button"
                key={cat.id}
                className={`cat-item ${isActive ? 'active' : ''}`}
                onClick={() => {
                  if (!isActive) triggerHaptic('tap');
                  setCurrentCategoryFilter(cat.id);
                }}
              >
                <div className="cat-icon-circle">{cat.icon || '🛒'}</div>
                <span className="cat-label">{cat.name}</span>
              </button>
            );
          })}
        </div>

        {/* ACTIVE TAB CONTENT */}
        {activeTab === 'home' && (
          <HomeTab
            settings={settings}
            freeDeliveryMinOrder={freeDeliveryMinOrder}
            currentCategoryFilter={currentCategoryFilter}
            categories={categories}
            filteredProducts={filteredProducts}
            approvedStores={approvedStores}
            allMenus={allMenus}
            favorites={customerProfile?.favorites}
            getItemQuantityInCart={getItemQuantityInCart}
            onFilterCategory={setCurrentCategoryFilter}
            onToggleFavorite={toggleFavoriteItem}
            onOpenProductDetail={(sId, iId) => {
              setDetailItemRef({ storeId: sId, itemId: iId });
              window.history.pushState({ modal: 'productDetail' }, '');
            }}
            onUpdateCart={updateCartQtySafe}
            onQuickAddStorePopular={handleQuickAddStorePopular}
            onOpenStoreModal={(sId) => {
              setMenuStoreId(sId);
              window.history.pushState({ modal: 'menu' }, '');
            }}
            pushPermission={pushPermission}
            pushPromptDismissed={promptDismissed}
            onEnablePush={() => void handleEnablePush()}
            onDismissPushPrompt={dismissPrompt}
          />
        )}

        {activeTab === 'orders' && (
          <OrdersTab
            groupedOrders={groupedOrders}
            cachedOrders={cachedOrders}
            stores={stores}
            deliveryPartners={deliveryPartners}
            timelineTimestamps={observedStatusTimestamps}
            gmpQuotaExceeded={gmpQuotaExceeded}
            onOpenRateRider={(groupKey) => {
              setRatingModalState({ mode: 'RIDER', groupKey });
              window.history.pushState({ modal: 'rating' }, '');
            }}
            onOpenRateProducts={(groupKey) => {
              setRatingModalState({ mode: 'PRODUCTS', groupKey });
              window.history.pushState({ modal: 'rating' }, '');
            }}
            onOpenCancelOrder={(groupKey) => {
              setCancelGroupKey(groupKey);
              window.history.pushState({ modal: 'cancel' }, '');
            }}
            onReorderOrder={handleReorderPastOrder}
          />
        )}

        {activeTab === 'wallet' && (
          <WalletTab
            walletBalance={Number(customerProfile?.walletBalance || 0)}
            minDeposit={minCustomerDeposit}
            maxDeposit={maxCustomerDeposit}
            minWithdraw={minCustomerWithdraw}
            maxWithdraw={maxCustomerWithdraw}
            allowReferrals={allowReferrals}
            referrerBonus={referrerBonus}
            refereeBonus={refereeBonus}
            referralCode={referralCode}
            transactions={walletTransactions}
            onOpenDeposit={() => {
              setIsDepositOpen(true);
              window.history.pushState({ modal: 'walletDep' }, '');
            }}
            onOpenWithdraw={() => {
              setIsWithdrawOpen(true);
              window.history.pushState({ modal: 'walletWd' }, '');
            }}
            onCopyReferral={() => {
              void navigator.clipboard
                ?.writeText(referralCode)
                .then(() =>
                  showToast(`Referral code ${referralCode} copied!`, 'success')
                );
            }}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileTab
            profile={customerProfile || {}}
            userEmail={currentUser?.email || customerProfile?.email || ''}
            referralCode={referralCode}
            hasGpsPinned={Boolean(detectedLat && detectedLng)}
            isDetectingGps={isDetectingProfileGps}
            settings={settings}
            myFeedbacks={myFeedbacks}
            pushPermission={pushPermission}
            unreadNotifications={unreadCount}
            onDetectGps={handleProfileGps}
            onSaveProfile={handleSaveProfile}
            onOpenFeedback={() => {
              setIsFeedbackOpen(true);
              window.history.pushState({ modal: 'feedback' }, '');
            }}
            onEnablePush={() => void handleEnablePush()}
            onSendTestPush={() => void handleSendTestPush()}
            onOpenNotificationInbox={() => {
              setIsInboxOpen(true);
              window.history.pushState({ modal: 'inbox' }, '');
            }}
            onSendPasswordReset={() => void handleSendPasswordReset()}
            onLogout={handleLogout}
          />
        )}

        {/* FLOATING CART BAR */}
        {totalCartCount > 0 && (
          <button
            type="button"
            id="cart-floating-bar"
            onClick={() => {
              triggerHaptic('tap');
              setIsCheckoutOpen(true);
              window.history.pushState({ modal: 'checkout' }, '');
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ fontSize: '1.3rem' }}>🛍️</span>
              <div>
                <span
                  id="floating-cart-count"
                  style={{ display: 'block', fontSize: '0.84rem', fontWeight: 900 }}
                >
                  {totalCartCount} ITEM{totalCartCount > 1 ? 'S' : ''}
                </span>
                <span
                  id="floating-cart-total"
                  style={{ fontSize: '1rem', fontWeight: 900 }}
                >
                  ₹{totalCartSubtotal.toFixed(0)}
                </span>
              </div>
            </div>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                fontSize: '0.92rem',
                fontWeight: 900,
              }}
            >
              <span>View Basket</span>
              <i
                className="fa-solid fa-chevron-right"
                style={{ fontSize: '0.8rem' }}
              />
            </div>
          </button>
        )}

        {/* BOTTOM NAVIGATION */}
        <nav className="bottom-nav" aria-label="Main navigation">
          <button
            type="button"
            className={`nav-btn ${activeTab === 'home' ? 'active' : ''}`}
            onClick={() => switchNav('home', true, true)}
          >
            <i className="fa-solid fa-bag-shopping" />
            <span>Bazar</span>
          </button>
          <button
            type="button"
            className={`nav-btn ${activeTab === 'orders' ? 'active' : ''}`}
            onClick={() => switchNav('orders', true, true)}
          >
            <i className="fa-solid fa-receipt" />
            <span>Orders</span>
          </button>
          <button
            type="button"
            className={`nav-btn ${activeTab === 'wallet' ? 'active' : ''}`}
            onClick={() => switchNav('wallet', true, true)}
          >
            <i className="fa-solid fa-wallet" />
            <span>Wallet</span>
          </button>
          <button
            type="button"
            className={`nav-btn ${activeTab === 'profile' ? 'active' : ''}`}
            onClick={() => switchNav('profile', true, true)}
          >
            <i className="fa-solid fa-user" />
            <span>Profile</span>
          </button>
        </nav>

        {/* MODALS */}
        <StoreMenuModal
          storeId={menuStoreId}
          stores={stores}
          allMenus={allMenus}
          favorites={customerProfile?.favorites}
          getItemQuantityInCart={getItemQuantityInCart}
          onClose={() => setMenuStoreId(null)}
          onToggleFavorite={toggleFavoriteItem}
          onOpenProductDetail={(sId, iId) => {
            setDetailItemRef({ storeId: sId, itemId: iId });
            window.history.pushState({ modal: 'productDetail' }, '');
          }}
          onUpdateCart={updateCartQtySafe}
        />

        <ProductDetailModal
          detailRef={detailItemRef}
          stores={stores}
          allMenus={allMenus}
          productReviews={productReviews}
          favorites={customerProfile?.favorites}
          getItemQuantityInCart={getItemQuantityInCart}
          onClose={() => setDetailItemRef(null)}
          onToggleFavorite={toggleFavoriteItem}
          onOpenProductDetail={(sId, iId) =>
            setDetailItemRef({ storeId: sId, itemId: iId })
          }
          onUpdateCart={updateCartQtySafe}
        />

        <CheckoutModal
          isOpen={isCheckoutOpen}
          cartItems={cartItems}
          stores={stores}
          walletBalance={Number(customerProfile?.walletBalance || 0)}
          adminUpiId={adminUpiId}
          usedUtrs={Array.from(collectKnownUtrs(cachedOrders, localUsedUtrs))}
          baseDeliveryCharge={baseDeliveryCharge}
          freeDeliveryMinOrder={freeDeliveryMinOrder}
          handlingFee={handlingFee}
          allowCod={allowCod}
          allowUpi={allowUpi}
          allowCoupons={allowCoupons}
          cmsCouponCode={cmsCouponCode}
          cmsCouponDiscount={cmsCouponDiscount}
          cmsCouponMinOrder={cmsCouponMinOrder}
          initialAddress={customerProfile?.address || ''}
          initialPhone={customerProfile?.phone || ''}
          hasGpsAttached={Boolean(detectedLat && detectedLng)}
          isFetchingGps={isFetchingCheckoutGps}
          isPlacingOrder={isPlacingOrder}
          onClose={() => setIsCheckoutOpen(false)}
          onUpdateCart={(itemId, storeId, change) =>
            updateCartQtySafe(itemId, storeId, change)
          }
          onFetchGps={handleCheckoutGps}
          onPlaceOrder={(p) => void handlePlaceOrder(p)}
          showToast={showToast}
        />

        <WalletDepositModal
          isOpen={isDepositOpen}
          adminUpiId={adminUpiId}
          usedUtrs={Array.from(collectKnownUtrs(cachedOrders, localUsedUtrs))}
          minDeposit={minCustomerDeposit}
          maxDeposit={maxCustomerDeposit}
          onClose={() => setIsDepositOpen(false)}
          onSubmit={(amt, utr, ss) =>
            void handleWalletDepositSubmit(amt, utr, ss)
          }
          showToast={showToast}
        />

        <WalletWithdrawModal
          isOpen={isWithdrawOpen}
          minWithdraw={minCustomerWithdraw}
          maxWithdraw={maxCustomerWithdraw}
          onClose={() => setIsWithdrawOpen(false)}
          onSubmit={(amt, upi) => void handleWalletWithdrawSubmit(amt, upi)}
        />

        <RatingModal
          mode={ratingModalState?.mode || null}
          group={activeRatingGroup}
          riderName={
            activeRatingGroup?.deliveryUid
              ? deliveryPartners[activeRatingGroup.deliveryUid]?.name ||
                'Delivery Partner'
              : 'Delivery Partner'
          }
          onClose={() => setRatingModalState(null)}
          onSubmitRiderRating={(g, stars, comment) =>
            void handleSubmitRiderRating(g, stars, comment)
          }
          onSubmitProductReviews={(g, revs) =>
            void handleSubmitProductReviews(g, revs)
          }
        />

        <FeedbackModal
          isOpen={isFeedbackOpen}
          onClose={() => setIsFeedbackOpen(false)}
          onSubmit={(sub, rat, msg) => void handleFeedbackSubmit(sub, rat, msg)}
        />

        <CancelOrderModal
          groupKey={cancelGroupKey}
          onClose={() => setCancelGroupKey(null)}
          onConfirmCancel={(gk, reason) =>
            void handleConfirmCancelOrder(gk, reason)
          }
        />

        <NotificationInboxModal
          isOpen={isInboxOpen}
          notifications={notifications}
          permission={pushPermission}
          onClose={() => setIsInboxOpen(false)}
          onEnablePush={() => void handleEnablePush()}
          onSendTestPush={() => void handleSendTestPush()}
          onMarkRead={markNotificationRead}
          onMarkAllRead={markAllRead}
          onClearAll={clearInbox}
          onSelectTargetTab={(tab) => switchNav(tab)}
        />
      </div>
    </>
  );
}
