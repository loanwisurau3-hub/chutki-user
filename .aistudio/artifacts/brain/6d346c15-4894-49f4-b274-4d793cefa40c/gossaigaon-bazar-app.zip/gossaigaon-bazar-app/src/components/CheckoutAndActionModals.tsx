import React, { useEffect, useState } from 'react';
import type { CartItem, GroupedOrder, Store } from '../types/bazar';
import {
  buildShareCartUrl,
  calculateCheckoutSummary,
  groupCartByStore,
} from '../utils/bazarLogic';
import { compressImageToDataUrl, DEFAULT_PRODUCT_IMG } from '../utils/imageUtils';
import { buildVerifiedUpiUri, validateUpiUtr } from '../utils/security';
import { triggerHaptic } from '../utils/haptics';

interface CheckoutModalProps {
  isOpen: boolean;
  cartItems: CartItem[];
  stores: Record<string, Store>;
  walletBalance: number;
  adminUpiId: string;
  usedUtrs?: string[];
  baseDeliveryCharge: number;
  freeDeliveryMinOrder: number;
  handlingFee: number;
  allowCod: boolean;
  allowUpi: boolean;
  allowCoupons: boolean;
  cmsCouponCode: string;
  cmsCouponDiscount: number;
  cmsCouponMinOrder: number;
  initialAddress: string;
  initialPhone: string;
  hasGpsAttached: boolean;
  isFetchingGps: boolean;
  isPlacingOrder: boolean;
  onClose: () => void;
  onUpdateCart: (itemId: string, storeId: string, change: number) => void;
  onFetchGps: () => void;
  onPlaceOrder: (payload: {
    address: string;
    phone: string;
    paymentMode: 'COD' | 'UPI' | 'WALLET';
    utr: string;
    screenshotData: string;
    appliedDiscount: number;
    appliedCouponCode: string;
  }) => void;
  showToast: (msg: string, type?: 'success' | 'danger' | 'info') => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  cartItems,
  stores,
  walletBalance,
  adminUpiId,
  usedUtrs,
  baseDeliveryCharge,
  freeDeliveryMinOrder,
  handlingFee,
  allowCod,
  allowUpi,
  allowCoupons,
  cmsCouponCode,
  cmsCouponDiscount,
  cmsCouponMinOrder,
  initialAddress,
  initialPhone,
  hasGpsAttached,
  isFetchingGps,
  isPlacingOrder,
  onClose,
  onUpdateCart,
  onFetchGps,
  onPlaceOrder,
  showToast,
}) => {
  const [address, setAddress] = useState(initialAddress);
  const [phone, setPhone] = useState(initialPhone);
  const [couponInput, setCouponInput] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState(0);
  const [appliedCouponCode, setAppliedCouponCode] = useState('');
  const [paymentMode, setPaymentMode] = useState<'COD' | 'UPI' | 'WALLET'>(
    allowCod ? 'COD' : allowUpi ? 'UPI' : 'WALLET'
  );
  const [utr, setUtr] = useState('');
  const [screenshotData, setScreenshotData] = useState('');
  const [isSharePanelOpen, setIsSharePanelOpen] = useState(false);
  const [shareCopied, setShareCopied] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setAddress(initialAddress);
      setPhone(initialPhone);
      setAppliedDiscount(0);
      setAppliedCouponCode('');
      setCouponInput('');
      setUtr('');
      setScreenshotData('');
      setIsSharePanelOpen(false);
      setShareCopied(false);
      setPaymentMode(allowCod ? 'COD' : allowUpi ? 'UPI' : 'WALLET');
    }
  }, [isOpen, initialAddress, initialPhone, allowCod, allowUpi]);

  if (!isOpen || cartItems.length === 0) return null;

  const groupedByStore = groupCartByStore(cartItems, stores);
  const summary = calculateCheckoutSummary({
    items: cartItems,
    stores,
    baseDeliveryCharge,
    freeDeliveryMinOrder,
    handlingFee,
    appliedDiscount,
  });

  const shareUrl = buildShareCartUrl(
    typeof window !== 'undefined' ? window.location.href : 'https://gossaigaonbazar.app/',
    cartItems
  );
  const totalUnitCount = cartItems.reduce((acc, item) => acc + item.qty, 0);
  const shareText = `Check out my Gossaigaon Bazar basket (${totalUnitCount} item${totalUnitCount > 1 ? 's' : ''}, ₹${summary.subtotal.toFixed(0)}): ${shareUrl}`;
  const whatsappShareUrl = `https://wa.me/?text=${encodeURIComponent(shareText)}`;
  const supportsNativeShare =
    typeof navigator !== 'undefined' && typeof navigator.share === 'function';

  const copyShareUrl = async (showFallbackToast = true) => {
    if (!shareUrl) return;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(shareUrl);
        triggerHaptic('tap');
        setShareCopied(true);
        showToast('🔗 Cart share link copied!', 'success');
        setTimeout(() => setShareCopied(false), 2500);
        return;
      }
    } catch {
      // Fallback toast below when clipboard access is blocked
    }
    if (showFallbackToast) {
      showToast('Share link ready—copy from the box above!', 'info');
    }
  };

  const handleOpenShareCart = () => {
    if (!shareUrl) return;
    triggerHaptic('tap');
    const nextOpen = !isSharePanelOpen;
    setIsSharePanelOpen(nextOpen);
    if (nextOpen) {
      void copyShareUrl(false);
    }
  };

  const handleNativeShare = async () => {
    if (!supportsNativeShare || !shareUrl) return;
    try {
      await navigator.share({
        title: 'Gossaigaon Bazar Basket',
        text: `Here is my grocery basket (${totalUnitCount} item${totalUnitCount > 1 ? 's' : ''}, ₹${summary.subtotal.toFixed(0)}):`,
        url: shareUrl,
      });
    } catch {
      // User dismissed share sheet
    }
  };

  const verifiedUpiString = buildVerifiedUpiUri({
    payeeVpa: adminUpiId,
    payeeName: 'GossaigaonBazar',
    amount: summary.netPayable,
  });
  const checkoutUtrCheck =
    utr.trim().length > 0 ? validateUpiUtr(utr, usedUtrs) : null;

  const handleApplyCoupon = () => {
    if (!allowCoupons) {
      triggerHaptic('tap');
      showToast('Coupons are disabled.', 'info');
      return;
    }
    const code = couponInput.trim().toUpperCase();
    const targetCode = cmsCouponCode || 'GOSSAIGAON20';
    const targetDiscount = cmsCouponDiscount > 0 ? cmsCouponDiscount : 20;
    const minOrd = cmsCouponMinOrder > 0 ? cmsCouponMinOrder : 100;
    if (code === targetCode) {
      if (summary.subtotal < minOrd) {
        triggerHaptic('error');
        showToast(`Min ₹${minOrd} required for ${targetCode}!`, 'danger');
        return;
      }
      setAppliedDiscount(targetDiscount);
      setAppliedCouponCode(code);
      triggerHaptic('success');
      showToast(`🎉 ₹${targetDiscount} Coupon Applied!`, 'success');
    } else {
      triggerHaptic('error');
      showToast(`Invalid Coupon! Try ${targetCode}`, 'danger');
    }
  };

  const handleScreenshotFile = async (file?: File) => {
    if (!file) return;
    try {
      const dataUrl = await compressImageToDataUrl(file);
      setScreenshotData(dataUrl);
      triggerHaptic('success');
      showToast('📸 Payment screenshot attached!', 'success');
    } catch (err) {
      triggerHaptic('error');
      showToast(err instanceof Error ? err.message : 'Invalid file', 'danger');
    }
  };

  return (
    <div id="checkout-modal" className="sheet-backdrop" onClick={onClose}>
      <div className="checkout-sheet" onClick={(e) => e.stopPropagation()}>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: '8px',
            marginBottom: '0.85rem',
          }}
        >
          <div style={{ minWidth: 0 }}>
            <h3 style={{ fontWeight: 900, fontSize: '1.2rem' }}>
              My Unified Basket
            </h3>
            <span
              id="checkout-store-name"
              style={{
                fontSize: '0.76rem',
                color: 'var(--text-muted)',
                fontWeight: 700,
              }}
            >
              {groupedByStore.length > 1
                ? `${groupedByStore.length} Stores in 1 Order`
                : `Store: ${groupedByStore[0]?.storeName}`}
            </span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexShrink: 0 }}>
            <button
              type="button"
              id="btn-share-cart"
              className={`btn btn-outline btn-sm share-cart-btn ${isSharePanelOpen ? 'active' : ''}`}
              aria-label="Share Cart"
              aria-expanded={isSharePanelOpen}
              onClick={handleOpenShareCart}
            >
              <i className="fa-solid fa-share-nodes" aria-hidden="true" />
              <span>Share Cart</span>
            </button>
            <button
              type="button"
              aria-label="Close checkout"
              onClick={onClose}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '1.3rem',
                cursor: 'pointer',
                color: '#64748b',
              }}
            >
              <i className="fa-solid fa-xmark" />
            </button>
          </div>
        </div>

        {isSharePanelOpen && shareUrl && (
          <section className="share-cart-panel" aria-label="Share Cart Link">
            <div className="share-cart-panel-head">
              <div>
                <div className="share-cart-title">Send Basket to Friends or Family</div>
                <div className="share-cart-subtitle">
                  Anyone with this link can load these {totalUnitCount} item
                  {totalUnitCount > 1 ? 's' : ''} right into their cart.
                </div>
              </div>
              <button
                type="button"
                className="share-cart-close-btn"
                aria-label="Close share cart panel"
                onClick={() => setIsSharePanelOpen(false)}
              >
                <i className="fa-solid fa-xmark" aria-hidden="true" />
              </button>
            </div>
            <div className="share-cart-url-row">
              <input
                type="text"
                readOnly
                id="share-cart-url-input"
                aria-label="Shareable cart URL"
                className="form-input share-cart-url-input"
                value={shareUrl}
                onFocus={(e) => e.currentTarget.select()}
              />
              <button
                type="button"
                id="btn-copy-share-cart"
                className="btn btn-primary btn-sm share-cart-copy-btn"
                aria-label="Copy cart link"
                onClick={() => void copyShareUrl()}
              >
                <i
                  className={shareCopied ? 'fa-solid fa-check' : 'fa-regular fa-copy'}
                  aria-hidden="true"
                />
                <span>{shareCopied ? 'Copied!' : 'Copy Link'}</span>
              </button>
            </div>
            <div className="share-cart-actions-row">
              <a
                href={whatsappShareUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-outline btn-sm share-cart-wa-link"
                aria-label="Share cart on WhatsApp"
              >
                <i className="fa-brands fa-whatsapp" aria-hidden="true" />
                <span>Send via WhatsApp</span>
              </a>
              {supportsNativeShare && (
                <button
                  type="button"
                  className="btn btn-outline btn-sm share-cart-native-btn"
                  aria-label="Share cart using device sheet"
                  onClick={() => void handleNativeShare()}
                >
                  <i className="fa-solid fa-arrow-up-from-bracket" aria-hidden="true" />
                  <span>More Options</span>
                </button>
              )}
            </div>
          </section>
        )}

        <div
          style={{
            background: 'var(--brand-green-light)',
            borderRadius: '12px',
            padding: '0.65rem 0.85rem',
            marginBottom: '0.85rem',
          }}
        >
          <div
            id="free-delivery-text"
            style={{
              fontSize: '0.76rem',
              fontWeight: 800,
              color: 'var(--brand-green)',
            }}
          >
            {summary.deliveryCharge === 0 ? (
              <>
                🎉 <strong>FREE Delivery Unlocked!</strong> (Saved ₹
                {baseDeliveryCharge})
              </>
            ) : (
              <>
                🚚 Add <strong>₹{summary.freeDeliveryRemaining.toFixed(0)}</strong>{' '}
                more for <strong>FREE Delivery!</strong>
              </>
            )}
          </div>
          <div
            style={{
              width: '100%',
              height: '6px',
              background: '#c8e6c9',
              borderRadius: '10px',
              marginTop: '5px',
              overflow: 'hidden',
            }}
          >
            <div
              id="free-delivery-bar"
              style={{
                height: '100%',
                width: `${summary.freeDeliveryProgressPercent}%`,
                background: 'var(--brand-green)',
              }}
            />
          </div>
        </div>

        <div
          id="checkout-items-list"
          style={{ maxHeight: '210px', overflowY: 'auto', marginBottom: '0.85rem' }}
        >
          {groupedByStore.map((storeGroup) => (
            <div
              key={storeGroup.storeId}
              className="store-basket-group"
              style={
                storeGroup.isClosed
                  ? { borderColor: 'var(--danger)', background: '#fef2f2' }
                  : undefined
              }
            >
              <div className="store-basket-header">
                <span>
                  <i className="fa-solid fa-store" /> {storeGroup.storeName}
                </span>
                {storeGroup.isClosed && (
                  <span style={{ color: 'var(--danger)', fontSize: '0.68rem' }}>
                    🔴 STORE CLOSED (Remove items)
                  </span>
                )}
              </div>
              {storeGroup.items.map((item) => (
                <div key={`${storeGroup.storeId}_${item.itemId}`} className="upgraded-cart-row">
                  <img
                    src={item.imageUrl || DEFAULT_PRODUCT_IMG}
                    className="cart-thumb-img"
                    onError={(e) => {
                      if (e.currentTarget.src !== DEFAULT_PRODUCT_IMG) {
                        e.currentTarget.src = DEFAULT_PRODUCT_IMG;
                      }
                    }}
                    alt={item.name}
                  />
                  <div style={{ flex: 1, padding: '0 6px' }}>
                    <div
                      style={{
                        fontSize: '0.86rem',
                        fontWeight: 800,
                        color: '#111',
                        lineHeight: 1.2,
                      }}
                    >
                      {item.name}
                    </div>
                    <div
                      style={{
                        fontSize: '0.74rem',
                        color: '#64748b',
                        marginTop: '2px',
                      }}
                    >
                      ₹{item.price} each
                    </div>
                  </div>
                  <div
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'flex-end',
                      gap: '4px',
                    }}
                  >
                    <strong style={{ fontSize: '0.95rem', color: '#111' }}>
                      ₹{(item.price * item.qty).toFixed(0)}
                    </strong>
                    <div className="qc-counter" style={{ borderRadius: '6px' }}>
                      <button
                        type="button"
                        className="qc-counter-btn"
                        style={{ padding: '3px 8px' }}
                        onClick={() =>
                          onUpdateCart(item.itemId, storeGroup.storeId, -1)
                        }
                      >
                        -
                      </button>
                      <span
                        className="qc-counter-val"
                        style={{ fontSize: '0.75rem' }}
                      >
                        {item.qty}
                      </span>
                      <button
                        type="button"
                        className="qc-counter-btn"
                        style={{ padding: '3px 8px' }}
                        onClick={() =>
                          onUpdateCart(item.itemId, storeGroup.storeId, 1)
                        }
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>

        {allowCoupons && (
          <div
            id="coupon-row-wrap"
            style={{ display: 'flex', gap: '8px', marginBottom: '0.85rem' }}
          >
            <input
              type="text"
              id="coupon-input"
              className="form-input"
              style={{
                padding: '0.5rem 0.75rem',
                fontSize: '0.82rem',
                textTransform: 'uppercase',
              }}
              placeholder={`Try Coupon: ${cmsCouponCode || 'GOSSAIGAON20'}`}
              value={couponInput}
              onChange={(e) => setCouponInput(e.target.value)}
            />
            <button
              type="button"
              className="btn btn-outline btn-sm"
              onClick={handleApplyCoupon}
              style={{ fontWeight: 900 }}
            >
              Apply
            </button>
          </div>
        )}

        <div
          style={{
            background: '#f8fafc',
            borderRadius: '14px',
            padding: '0.85rem',
            marginBottom: '0.85rem',
            border: '1px solid var(--border)',
          }}
        >
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '4px',
            }}
          >
            <label
              htmlFor="checkout-address"
              style={{
                fontSize: '0.74rem',
                fontWeight: 900,
                color: '#475569',
                margin: 0,
              }}
            >
              DELIVERY ADDRESS
            </label>
            <button
              type="button"
              className="btn btn-outline btn-sm"
              id="btn-checkout-gps"
              disabled={isFetchingGps}
              onClick={onFetchGps}
              style={{
                color: 'var(--brand-green)',
                borderColor: 'var(--brand-green)',
              }}
            >
              <i
                className={
                  isFetchingGps
                    ? 'fa-solid fa-satellite-dish fa-spin'
                    : hasGpsAttached
                      ? 'fa-solid fa-circle-check'
                      : 'fa-solid fa-location-crosshairs'
                }
              />{' '}
              {isFetchingGps
                ? 'Pinpointing...'
                : hasGpsAttached
                  ? 'GPS Attached'
                  : 'Use Current GPS'}
            </button>
          </div>
          <input
            type="text"
            id="checkout-address"
            className="form-input"
            style={{ padding: '0.6rem', marginBottom: '6px' }}
            placeholder="House/Flat No, Landmark, Road name..."
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            required
          />
          {hasGpsAttached && (
            <div
              id="checkout-gps-status"
              style={{
                background: '#e8f5e9',
                border: '1px solid #a7f3d0',
                borderRadius: '8px',
                padding: '5px 9px',
                fontSize: '0.72rem',
                color: '#065f46',
                fontWeight: 800,
                marginBottom: '6px',
              }}
            >
              <i className="fa-solid fa-satellite" /> Doorstep GPS Attached
            </div>
          )}
          <label
            htmlFor="checkout-phone"
            style={{
              fontSize: '0.72rem',
              fontWeight: 800,
              color: '#64748b',
              marginBottom: '2px',
              display: 'block',
            }}
          >
            10-DIGIT MOBILE NUMBER
          </label>
          <input
            type="tel"
            id="checkout-phone"
            className="form-input"
            style={{ padding: '0.6rem' }}
            maxLength={10}
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            required
          />
        </div>

        <div style={{ marginBottom: '0.85rem' }}>
          <label
            style={{
              fontSize: '0.74rem',
              fontWeight: 900,
              color: '#475569',
              display: 'block',
              marginBottom: '6px',
            }}
          >
            PAYMENT METHOD
          </label>
          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
            {allowCod && (
              <button
                type="button"
                id="pay-card-cod"
                className="btn btn-outline btn-sm"
                style={{
                  flex: 1,
                  fontWeight: 900,
                  background:
                    paymentMode === 'COD'
                      ? 'var(--brand-green-light)'
                      : 'transparent',
                  borderColor:
                    paymentMode === 'COD'
                      ? 'var(--brand-green)'
                      : 'var(--border)',
                  color:
                    paymentMode === 'COD' ? 'var(--brand-green)' : '#111',
                }}
                onClick={() => {
                  if (paymentMode !== 'COD') triggerHaptic('tap');
                  setPaymentMode('COD');
                }}
              >
                💵 COD
              </button>
            )}
            {allowUpi && (
              <button
                type="button"
                id="pay-card-upi"
                className="btn btn-outline btn-sm"
                style={{
                  flex: 1,
                  fontWeight: 900,
                  background:
                    paymentMode === 'UPI'
                      ? 'var(--brand-green-light)'
                      : 'transparent',
                  borderColor:
                    paymentMode === 'UPI'
                      ? 'var(--brand-green)'
                      : 'var(--border)',
                  color:
                    paymentMode === 'UPI' ? 'var(--brand-green)' : '#111',
                }}
                onClick={() => {
                  if (paymentMode !== 'UPI') triggerHaptic('tap');
                  setPaymentMode('UPI');
                }}
              >
                📱 UPI App
              </button>
            )}
            <button
              type="button"
              id="pay-card-wallet"
              className="btn btn-outline btn-sm"
              style={{
                flex: 1,
                fontWeight: 900,
                background:
                  paymentMode === 'WALLET'
                    ? 'var(--brand-green-light)'
                    : 'transparent',
                borderColor:
                  paymentMode === 'WALLET'
                    ? 'var(--brand-green)'
                    : 'var(--border)',
                color:
                  paymentMode === 'WALLET' ? 'var(--brand-green)' : '#111',
              }}
              onClick={() => {
                if (paymentMode !== 'WALLET') triggerHaptic('tap');
                setPaymentMode('WALLET');
              }}
            >
              💳 Wallet
            </button>
          </div>
        </div>

        {paymentMode === 'UPI' && (
          <div
            id="upi-details-container"
            style={{
              background: '#f8fafc',
              border: '1px dashed var(--brand-green)',
              borderRadius: '14px',
              padding: '0.85rem',
              textAlign: 'center',
              marginBottom: '0.85rem',
            }}
          >
            <div style={{ fontSize: '0.78rem', fontWeight: 800 }}>
              Scan QR or Open UPI App Directly
            </div>
            {verifiedUpiString ? (
              <>
                <img
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=130x130&data=${encodeURIComponent(verifiedUpiString)}`}
                  id="upi-qr-image"
                  style={{
                    width: '130px',
                    height: '130px',
                    margin: '6px auto',
                    display: 'block',
                    background: '#fff',
                    padding: '4px',
                    borderRadius: '10px',
                  }}
                  alt="UPI QR"
                />
                <a
                  href={verifiedUpiString}
                  id="upi-open-app-link"
                  className="btn btn-primary btn-sm"
                  style={{ width: '100%', marginBottom: '8px' }}
                >
                  <i className="fa-solid fa-mobile-screen-button" /> Open UPI App
                  (GPay / PhonePe / Paytm)
                </a>
              </>
            ) : (
              <div className="utr-security-warning" role="alert" style={{ margin: '8px 0' }}>
                <i className="fa-solid fa-triangle-exclamation" aria-hidden="true" />{' '}
                Merchant UPI verification unavailable for this amount. Use COD or Wallet.
              </div>
            )}
            <input
              type="text"
              inputMode="numeric"
              id="checkout-utr"
              className="form-input"
              placeholder="Enter 12-Digit UPI UTR No."
              maxLength={12}
              value={utr}
              onChange={(e) => setUtr(e.target.value.replace(/\D/g, '').slice(0, 12))}
              style={{
                marginBottom: checkoutUtrCheck && !checkoutUtrCheck.valid ? '4px' : '8px',
                fontWeight: 800,
                textAlign: 'center',
              }}
            />
            {checkoutUtrCheck && !checkoutUtrCheck.valid && (
              <div className="utr-security-warning" role="alert" style={{ marginBottom: '8px' }}>
                <i className="fa-solid fa-shield-halved" aria-hidden="true" />{' '}
                {checkoutUtrCheck.reason}
              </div>
            )}
            <div
              style={{
                textAlign: 'left',
                background: '#fff',
                border: '1px solid var(--border)',
                borderRadius: '10px',
                padding: '8px',
              }}
            >
              <label
                htmlFor="checkout-upi-screenshot"
                style={{
                  fontSize: '0.7rem',
                  fontWeight: 800,
                  color: '#475569',
                  display: 'block',
                  marginBottom: '4px',
                }}
              >
                📸 Upload Payment Screenshot (Recommended)
              </label>
              <input
                type="file"
                id="checkout-upi-screenshot"
                accept="image/*"
                style={{ fontSize: '0.75rem', width: '100%' }}
                onChange={(e) => void handleScreenshotFile(e.target.files?.[0])}
              />
              {screenshotData && (
                <img
                  id="checkout-ss-preview"
                  src={screenshotData}
                  style={{
                    maxHeight: '90px',
                    marginTop: '6px',
                    borderRadius: '8px',
                    border: '1px solid var(--border)',
                  }}
                  alt="Screenshot Preview"
                />
              )}
            </div>
          </div>
        )}

        {paymentMode === 'WALLET' && (
          <div
            id="wallet-pay-info"
            style={{
              background: '#ecfdf5',
              border: '1px solid var(--brand-green)',
              borderRadius: '12px',
              padding: '0.75rem',
              marginBottom: '0.85rem',
              fontSize: '0.82rem',
              fontWeight: 800,
              color: '#065f46',
            }}
          >
            💳 Wallet Balance Available:{' '}
            <span id="checkout-wallet-bal">₹{walletBalance.toFixed(2)}</span>
          </div>
        )}

        <section
          id="checkout-order-summary"
          className="order-summary-card"
          aria-labelledby="order-summary-heading"
        >
          <div className="order-summary-head">
            <h4 id="order-summary-heading" className="order-summary-title">
              <i className="fa-solid fa-receipt" aria-hidden="true" /> Order Summary
            </h4>
            {summary.storeDiscount + summary.couponDiscount > 0 && (
              <span className="order-summary-savings">
                Saved ₹{(summary.storeDiscount + summary.couponDiscount).toFixed(0)}
              </span>
            )}
          </div>
          <table className="order-summary-table">
            <tbody>
              <tr>
                <th scope="row">Items Subtotal ({totalUnitCount} item{totalUnitCount > 1 ? 's' : ''})</th>
                <td id="checkout-subtotal-amount">₹{summary.subtotal.toFixed(0)}</td>
              </tr>
              <tr>
                <th scope="row">Delivery Charge</th>
                <td id="checkout-delivery-charge">
                  {summary.deliveryCharge === 0 ? (
                    <span className="summary-free-tag">FREE</span>
                  ) : (
                    `₹${summary.deliveryCharge.toFixed(0)}`
                  )}
                </td>
              </tr>
              <tr id="handling-fee-row">
                <th scope="row">Handling Fee</th>
                <td id="checkout-handling-fee">
                  {summary.handlingFee === 0 ? (
                    <span className="summary-free-tag">FREE</span>
                  ) : (
                    `₹${summary.handlingFee.toFixed(0)}`
                  )}
                </td>
              </tr>
              {summary.storeDiscount > 0 && (
                <tr id="store-discount-row" className="order-summary-discount-row">
                  <th scope="row">Store Offer Discount</th>
                  <td id="checkout-store-discount">
                    -₹{summary.storeDiscount.toFixed(0)}
                  </td>
                </tr>
              )}
              {summary.couponDiscount > 0 && (
                <tr id="coupon-discount-row" className="order-summary-discount-row">
                  <th scope="row">
                    Coupon Discount{appliedCouponCode ? ` (${appliedCouponCode})` : ''}
                  </th>
                  <td id="checkout-discount-amount">
                    -₹{summary.couponDiscount.toFixed(0)}
                  </td>
                </tr>
              )}
            </tbody>
            <tfoot>
              <tr>
                <th scope="row">Total Payable</th>
                <td id="checkout-total-amount">₹{summary.netPayable.toFixed(0)}</td>
              </tr>
            </tfoot>
          </table>
        </section>

        <div className="checkout-security-note">
          <i className="fa-solid fa-shield-halved" aria-hidden="true" />
          <span>
            Price-locked &amp; PIN-protected • Never share your Delivery PIN or UPI PIN with anyone.
          </span>
        </div>

        <button
          type="button"
          className="btn btn-primary"
          disabled={isPlacingOrder}
          onClick={() =>
            onPlaceOrder({
              address,
              phone,
              paymentMode,
              utr,
              screenshotData,
              appliedDiscount,
              appliedCouponCode,
            })
          }
          id="btn-place-order"
          style={{ padding: '0.95rem', fontSize: '1rem', fontWeight: 900 }}
        >
          {isPlacingOrder ? (
            <>
              <i className="fa-solid fa-spinner fa-spin" /> Placing Order...
            </>
          ) : (
            'Place 15-Minute Order'
          )}
        </button>
      </div>
    </div>
  );
};

interface WalletDepositModalProps {
  isOpen: boolean;
  adminUpiId: string;
  usedUtrs?: string[];
  minDeposit: number;
  maxDeposit: number;
  onClose: () => void;
  onSubmit: (amt: number, utr: string, screenshotData: string) => void;
  showToast: (msg: string, type?: 'success' | 'danger' | 'info') => void;
}

export const WalletDepositModal: React.FC<WalletDepositModalProps> = ({
  isOpen,
  adminUpiId,
  usedUtrs,
  minDeposit,
  maxDeposit,
  onClose,
  onSubmit,
  showToast,
}) => {
  const [amt, setAmt] = useState(String(minDeposit));
  const [utr, setUtr] = useState('');
  const [screenshotData, setScreenshotData] = useState('');

  useEffect(() => {
    if (isOpen) {
      setAmt(String(minDeposit));
      setUtr('');
      setScreenshotData('');
    }
  }, [isOpen, minDeposit]);

  if (!isOpen) return null;
  const numericAmt = Math.max(1, Number(amt || minDeposit));
  const verifiedWalletUpi = buildVerifiedUpiUri({
    payeeVpa: adminUpiId,
    payeeName: 'GossaigaonBazarWallet',
    amount: numericAmt,
    maxAmount: Math.max(maxDeposit, 50000),
  });
  const walletUtrCheck =
    utr.trim().length > 0 ? validateUpiUtr(utr, usedUtrs) : null;

  return (
    <div id="wallet-deposit-modal" className="sheet-backdrop" onClick={onClose}>
      <div className="checkout-sheet" onClick={(e) => e.stopPropagation()}>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '0.85rem',
          }}
        >
          <h3 style={{ fontWeight: 900 }}>Add Money to Wallet</h3>
          <button
            type="button"
            aria-label="Close deposit modal"
            onClick={onClose}
            style={{ background: 'none', border: 'none', fontSize: '1.3rem', cursor: 'pointer' }}
          >
            <i className="fa-solid fa-xmark" />
          </button>
        </div>
        <div className="form-group">
          <label id="wallet-dep-limit-label" htmlFor="wallet-dep-amt">
            Enter Deposit Amount (Min ₹{minDeposit} - Max ₹{maxDeposit})
          </label>
          <input
            type="number"
            id="wallet-dep-amt"
            className="form-input"
            placeholder="e.g. 200"
            value={amt}
            onChange={(e) => setAmt(e.target.value)}
          />
        </div>
        <div
          style={{
            textAlign: 'center',
            background: '#f8fafc',
            border: '1px dashed var(--brand-green)',
            borderRadius: '14px',
            padding: '0.85rem',
            marginBottom: '0.85rem',
          }}
        >
          {verifiedWalletUpi ? (
            <>
              <img
                id="wallet-dep-qr"
                src={`https://api.qrserver.com/v1/create-qr-code/?size=130x130&data=${encodeURIComponent(verifiedWalletUpi)}`}
                style={{
                  width: '130px',
                  height: '130px',
                  margin: '0 auto 8px',
                  display: 'block',
                }}
                alt="UPI QR"
              />
              <a
                id="wallet-dep-upi-link"
                href={verifiedWalletUpi}
                className="btn btn-primary btn-sm"
                style={{ width: '100%', marginBottom: '8px' }}
              >
                📲 Open UPI App & Pay
              </a>
            </>
          ) : (
            <div className="utr-security-warning" role="alert" style={{ marginBottom: '8px' }}>
              <i className="fa-solid fa-triangle-exclamation" aria-hidden="true" />{' '}
              Enter a valid amount within limits to unlock verified merchant UPI payment.
            </div>
          )}
          <input
            type="text"
            inputMode="numeric"
            id="wallet-dep-utr"
            className="form-input"
            placeholder="Enter 12-Digit UTR Number"
            maxLength={12}
            value={utr}
            onChange={(e) => setUtr(e.target.value.replace(/\D/g, '').slice(0, 12))}
            style={{
              marginBottom: walletUtrCheck && !walletUtrCheck.valid ? '4px' : '8px',
              textAlign: 'center',
              fontWeight: 800,
            }}
          />
          {walletUtrCheck && !walletUtrCheck.valid && (
            <div className="utr-security-warning" role="alert" style={{ marginBottom: '8px' }}>
              <i className="fa-solid fa-shield-halved" aria-hidden="true" />{' '}
              {walletUtrCheck.reason}
            </div>
          )}
          <input
            type="file"
            id="wallet-dep-ss"
            accept="image/*"
            style={{ fontSize: '0.75rem', width: '100%' }}
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              void compressImageToDataUrl(file)
                .then((d) => {
                  setScreenshotData(d);
                  showToast('📸 Deposit screenshot attached!', 'success');
                })
                .catch((err) =>
                  showToast(err instanceof Error ? err.message : 'Invalid image', 'danger')
                );
            }}
          />
        </div>
        <button
          type="button"
          className="btn btn-primary"
          onClick={() => onSubmit(Number(amt || 0), utr.trim(), screenshotData)}
        >
          Submit Deposit Request
        </button>
      </div>
    </div>
  );
};

interface WalletWithdrawModalProps {
  isOpen: boolean;
  minWithdraw: number;
  maxWithdraw: number;
  onClose: () => void;
  onSubmit: (amt: number, upiId: string) => void;
}

export const WalletWithdrawModal: React.FC<WalletWithdrawModalProps> = ({
  isOpen,
  minWithdraw,
  maxWithdraw,
  onClose,
  onSubmit,
}) => {
  const [amt, setAmt] = useState('');
  const [upiId, setUpiId] = useState('');

  useEffect(() => {
    if (isOpen) {
      setAmt('');
      setUpiId('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div id="wallet-withdraw-modal" className="sheet-backdrop" onClick={onClose}>
      <div className="checkout-sheet" onClick={(e) => e.stopPropagation()}>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '0.85rem',
          }}
        >
          <h3 style={{ fontWeight: 900 }}>Withdraw Wallet Money</h3>
          <button
            type="button"
            aria-label="Close withdraw modal"
            onClick={onClose}
            style={{ background: 'none', border: 'none', fontSize: '1.3rem', cursor: 'pointer' }}
          >
            <i className="fa-solid fa-xmark" />
          </button>
        </div>
        <div className="form-group">
          <label id="wallet-wd-limit-label" htmlFor="wallet-wd-amt">
            Withdraw Amount (Min ₹{minWithdraw} - Max ₹{maxWithdraw})
          </label>
          <input
            type="number"
            id="wallet-wd-amt"
            className="form-input"
            placeholder="e.g. 100"
            value={amt}
            onChange={(e) => setAmt(e.target.value)}
          />
        </div>
        <div className="form-group">
          <label htmlFor="wallet-wd-upi">Your Receiving UPI ID</label>
          <input
            type="text"
            id="wallet-wd-upi"
            className="form-input"
            placeholder="e.g. 9876543210@paytm"
            value={upiId}
            onChange={(e) => setUpiId(e.target.value)}
          />
        </div>
        <button
          type="button"
          className="btn btn-primary"
          onClick={() => onSubmit(Number(amt || 0), upiId.trim())}
        >
          Submit Withdrawal Request
        </button>
      </div>
    </div>
  );
};

interface RatingModalProps {
  mode: 'RIDER' | 'PRODUCTS' | null;
  group: GroupedOrder | null;
  riderName: string;
  onClose: () => void;
  onSubmitRiderRating: (group: GroupedOrder, stars: number, comment: string) => void;
  onSubmitProductReviews: (
    group: GroupedOrder,
    reviews: Record<string, { rating: number; review: string }>
  ) => void;
}

export const RatingModal: React.FC<RatingModalProps> = ({
  mode,
  group,
  riderName,
  onClose,
  onSubmitRiderRating,
  onSubmitProductReviews,
}) => {
  const [stars, setStars] = useState(5);
  const [comment, setComment] = useState('');
  const [prodInputs, setProdInputs] = useState<
    Record<string, { rating: number; review: string }>
  >({});

  useEffect(() => {
    setStars(5);
    setComment('');
    setProdInputs({});
  }, [mode, group?.groupKey]);

  if (!mode || !group) return null;

  return (
    <div id="rating-modal" className="sheet-backdrop" onClick={onClose}>
      <div className="checkout-sheet" onClick={(e) => e.stopPropagation()}>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '0.85rem',
          }}
        >
          <h3 id="rating-modal-title" style={{ fontWeight: 900 }}>
            {mode === 'RIDER'
              ? `Rate Rider: ${riderName}`
              : 'Review Ordered Products'}
          </h3>
          <button
            type="button"
            aria-label="Close rating modal"
            onClick={onClose}
            style={{ background: 'none', border: 'none', fontSize: '1.3rem', cursor: 'pointer' }}
          >
            <i className="fa-solid fa-xmark" />
          </button>
        </div>

        <div id="rating-modal-body">
          {mode === 'RIDER' ? (
            <>
              <div style={{ textAlign: 'center', marginBottom: '1rem' }}>
                <div
                  id="rider-star-picker"
                  className="star-row"
                  style={{ justifyContent: 'center' }}
                >
                  {[1, 2, 3, 4, 5].map((n) => (
                    <i
                      key={n}
                      className={`fa-solid fa-star ${n <= stars ? 'lit' : ''}`}
                      onClick={() => setStars(n)}
                    />
                  ))}
                </div>
                <small style={{ color: 'var(--text-muted)' }}>
                  Tap stars to rate delivery speed & behaviour
                </small>
              </div>
              <div className="form-group">
                <label htmlFor="rider-rate-comment">Comment (Optional)</label>
                <textarea
                  id="rider-rate-comment"
                  className="form-input"
                  rows={2}
                  placeholder="Polite and fast delivery!"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                />
              </div>
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => onSubmitRiderRating(group, stars, comment)}
              >
                Submit Rider Rating
              </button>
            </>
          ) : (
            <>
              {group.orders.map((o, oIdx) => {
                const raw = Array.isArray(o.items)
                  ? o.items
                  : Object.values(o.items || {});
                return raw.map((item, iIdx) => {
                  const uidKey = `${oIdx}_${iIdx}`;
                  const cur = prodInputs[uidKey] || { rating: 5, review: '' };
                  return (
                    <div
                      key={uidKey}
                      style={{
                        background: '#f8fafc',
                        border: '1px solid var(--border)',
                        borderRadius: '12px',
                        padding: '0.75rem',
                        marginBottom: '0.75rem',
                      }}
                    >
                      <strong
                        style={{
                          fontSize: '0.86rem',
                          display: 'block',
                          marginBottom: '4px',
                        }}
                      >
                        {item.name}
                      </strong>
                      <select
                        className="form-input"
                        style={{
                          padding: '0.45rem',
                          marginBottom: '6px',
                          fontSize: '0.82rem',
                        }}
                        value={cur.rating}
                        onChange={(e) =>
                          setProdInputs((prev) => ({
                            ...prev,
                            [uidKey]: { ...cur, rating: Number(e.target.value) },
                          }))
                        }
                      >
                        <option value={5}>⭐⭐⭐⭐⭐ 5 - Excellent</option>
                        <option value={4}>⭐⭐⭐⭐ 4 - Good</option>
                        <option value={3}>⭐⭐⭐ 3 - Okay</option>
                        <option value={2}>⭐⭐ 2 - Poor</option>
                        <option value={1}>⭐ 1 - Bad</option>
                      </select>
                      <input
                        type="text"
                        className="form-input"
                        style={{ padding: '0.5rem', fontSize: '0.8rem' }}
                        placeholder="Write a short review..."
                        value={cur.review}
                        onChange={(e) =>
                          setProdInputs((prev) => ({
                            ...prev,
                            [uidKey]: { ...cur, review: e.target.value },
                          }))
                        }
                      />
                    </div>
                  );
                });
              })}
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => onSubmitProductReviews(group, prodInputs)}
              >
                Submit All Reviews
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (subject: string, rating: number, message: string) => void;
}

export const FeedbackModal: React.FC<FeedbackModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
}) => {
  const [subject, setSubject] = useState('');
  const [rating, setRating] = useState(5);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (isOpen) {
      setSubject('');
      setRating(5);
      setMessage('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div id="feedback-modal" className="sheet-backdrop" onClick={onClose}>
      <div className="checkout-sheet" onClick={(e) => e.stopPropagation()}>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '0.85rem',
          }}
        >
          <h3 style={{ fontWeight: 900 }}>Helpline & Feedback</h3>
          <button
            type="button"
            aria-label="Close feedback modal"
            onClick={onClose}
            style={{ background: 'none', border: 'none', fontSize: '1.3rem', cursor: 'pointer' }}
          >
            <i className="fa-solid fa-xmark" />
          </button>
        </div>
        <form
          id="customer-feedback-form"
          onSubmit={(e) => {
            e.preventDefault();
            onSubmit(subject, rating, message);
          }}
        >
          <div className="form-group">
            <label htmlFor="fb-subject">Subject</label>
            <input
              type="text"
              id="fb-subject"
              className="form-input"
              placeholder="Order issue / App suggestion"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="fb-rating">App Experience Rating</label>
            <select
              id="fb-rating"
              className="form-input"
              value={rating}
              onChange={(e) => setRating(Number(e.target.value))}
            >
              <option value={5}>⭐⭐⭐⭐⭐ Excellent (5)</option>
              <option value={4}>⭐⭐⭐⭐ Good (4)</option>
              <option value={3}>⭐⭐⭐ Average (3)</option>
              <option value={2}>⭐⭐ Poor (2)</option>
              <option value={1}>⭐ Very Bad (1)</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="fb-message">Message</label>
            <textarea
              id="fb-message"
              className="form-input"
              rows={3}
              placeholder="Describe your feedback or issue..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary">
            Send to Admin Helpline
          </button>
        </form>
      </div>
    </div>
  );
};

interface CancelOrderModalProps {
  groupKey: string | null;
  onClose: () => void;
  onConfirmCancel: (groupKey: string, reason: string) => void;
}

export const CancelOrderModal: React.FC<CancelOrderModalProps> = ({
  groupKey,
  onClose,
  onConfirmCancel,
}) => {
  const [reason, setReason] = useState('Ordered by mistake');

  if (!groupKey) return null;

  return (
    <div id="cancel-order-modal" className="sheet-backdrop" onClick={onClose}>
      <div className="checkout-sheet" onClick={(e) => e.stopPropagation()}>
        <h4
          style={{ fontWeight: 900, color: 'var(--danger)', marginBottom: '0.5rem' }}
        >
          Cancel Order?
        </h4>
        <p style={{ fontSize: '0.8rem', color: '#64748b', marginBottom: '1rem' }}>
          Please select a reason:
        </p>
        <div className="form-group">
          <select
            id="cancel-reason-select"
            className="form-input"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
          >
            <option value="Ordered by mistake">Ordered by mistake</option>
            <option value="Want to change items">Want to change items</option>
            <option value="Address entered wrongly">Address entered wrongly</option>
            <option value="Payment problem">Payment problem</option>
          </select>
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button type="button" className="btn btn-outline" onClick={onClose}>
            Don&apos;t Cancel
          </button>
          <button
            type="button"
            className="btn btn-danger"
            onClick={() => onConfirmCancel(groupKey, reason)}
          >
            Cancel Order
          </button>
        </div>
      </div>
    </div>
  );
};
