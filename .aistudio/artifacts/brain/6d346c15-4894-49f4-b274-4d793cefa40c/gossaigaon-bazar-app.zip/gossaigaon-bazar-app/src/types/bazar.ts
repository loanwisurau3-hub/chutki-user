export interface CategoryDef {
  id: string;
  name: string;
  icon: string;
  keywords: string[];
  active?: boolean;
}

export interface Store {
  name?: string;
  cuisine?: string;
  category?: string;
  imageUrl?: string;
  approved?: boolean;
  suspended?: boolean;
  isOpen?: boolean;
  lat?: number;
  lng?: number;
  storeDiscountPercent?: number;
  storeDiscountMinOrder?: number;
}

export interface MenuItem {
  itemId: string;
  storeId: string;
  storeName?: string;
  name: string;
  description?: string;
  searchKeywords?: string;
  category?: string;
  price: number;
  mrp?: number;
  discountPercent?: number;
  isOnSale?: boolean;
  saleBadgeText?: string;
  imageUrl?: string;
  available?: boolean;
  adminApproved?: boolean;
  ratingAvg?: number;
  ratingCount?: number;
}

export interface CartItem {
  itemId: string;
  name: string;
  price: number;
  qty: number;
  imageUrl: string;
  storeId: string;
  storeName: string;
}

export interface CustomerProfile {
  name?: string;
  email?: string;
  phone?: string;
  address?: string;
  lat?: number | null;
  lng?: number | null;
  locationLink?: string;
  referralCode?: string;
  referredBy?: string;
  walletBalance?: number;
  favorites?: Record<string, boolean>;
  blocked?: boolean;
  createdAt?: number;
  updatedAt?: number;
  fcmToken?: string;
  pushEnabled?: boolean;
}

export interface DeliveryPartner {
  name?: string;
  phone?: string;
  vehicle?: string;
  approved?: boolean;
  online?: boolean;
  suspended?: boolean;
  lat?: number;
  lng?: number;
  ratingAvg?: number;
  ratingCount?: number;
  lastLocationUpdate?: number;
}

export interface OrderRecord {
  orderId: string;
  batchGroupId?: string;
  customerUid: string;
  restaurantId: string;
  deliveryUid?: string | null;
  riderLat?: number | null;
  riderLng?: number | null;
  assignedAt?: number | null;
  items: CartItem[] | Record<string, CartItem>;
  subtotalAmount?: number;
  deliveryCharge?: number;
  handlingFee?: number;
  storeDiscountAmount?: number;
  discountAmount?: number;
  couponCode?: string;
  totalAmount: number;
  address?: string;
  phone?: string;
  customerLat?: number | null;
  customerLng?: number | null;
  locationLink?: string;
  deliveryOtp?: string;
  status: string;
  paymentMode?: string;
  paymentStatus?: string;
  transactionId?: string;
  paymentScreenshot?: string;
  isSpamSuspect?: boolean;
  spamReason?: string;
  emergencyAlert?: boolean;
  emergencyDetails?: string;
  riderRating?: number;
  riderReview?: string;
  productsReviewed?: boolean;
  placedAt?: number;
  acceptedAt?: number;
  preparingAt?: number;
  packingAt?: number;
  readyAt?: number;
  outForDeliveryAt?: number;
  deliveredAt?: number;
  cancelledAt?: number;
  statusTimestamps?: Record<string, number>;
  createdAt?: number;
  updatedAt?: number;
}

export interface GroupedOrder {
  groupKey: string;
  orders: OrderRecord[];
  placedAt?: number;
  statusTimestamps?: Record<string, number>;
  createdAt: number;
  deliveryOtp: string;
  paymentMode: string;
  phone: string;
  address: string;
  totalAmount: number;
  deliveryUid: string | null;
  riderLat: number | null;
  riderLng: number | null;
  customerLat: number | null;
  customerLng: number | null;
  locationLink: string;
  emergencyAlert: boolean;
  emergencyDetails: string;
}

export interface ProductReview {
  customerName?: string;
  rating: number;
  review?: string;
  createdAt?: number;
}

export interface WalletTransaction {
  type: 'CREDIT' | 'DEBIT';
  amount: number;
  note?: string;
  createdAt?: number;
}

export interface FeedbackItem {
  id?: string;
  role?: string;
  uid?: string;
  name?: string;
  phone?: string;
  subject: string;
  rating: number;
  message: string;
  status: string;
  adminReply?: string;
  createdAt?: number;
}

export interface AdminSettings {
  themePrimaryColor?: string;
  themeAccentColor?: string;
  themeBgColor?: string;
  appBrandName?: string;
  expressEtaText?: string;
  expressLocalBadge?: string;
  searchPlaceholder?: string;
  upiId?: string;
  deliveryCharge?: number;
  freeDeliveryAbove?: number;
  handlingFee?: number;
  minOrderAmount?: number;
  minCustomerDeposit?: number;
  maxCustomerDeposit?: number;
  minCustomerWithdraw?: number;
  maxCustomerWithdraw?: number;
  allowReferrals?: boolean;
  referrerBonus?: number;
  refereeBonus?: number;
  showHeroBanner?: boolean;
  heroTitle?: string;
  heroSubtitle?: string;
  heroTag?: string;
  heroEmoji?: string;
  extraBannerText?: string;
  customBannerImageUrl?: string;
  activeCouponCode?: string;
  activeCouponDiscount?: number;
  couponMinOrder?: number;
  allowCod?: boolean;
  allowUpi?: boolean;
  allowCoupons?: boolean;
  allowVoiceSearch?: boolean;
  maintenanceMode?: boolean;
  maintenanceMessage?: string;
  announcementActive?: boolean;
  announcementText?: string;
  customCategories?: CategoryDef[];
  supportPhone?: string;
  supportWhatsapp?: string;
  supportHours?: string;
}

export interface AppNotification {
  id: string;
  title: string;
  body: string;
  tag: string;
  type: 'ORDER' | 'WALLET' | 'PROMO' | 'SYSTEM';
  targetTab?: 'home' | 'orders' | 'wallet' | 'profile';
  createdAt: number;
  read: boolean;
}

export type TabKey = 'home' | 'orders' | 'wallet' | 'profile';
