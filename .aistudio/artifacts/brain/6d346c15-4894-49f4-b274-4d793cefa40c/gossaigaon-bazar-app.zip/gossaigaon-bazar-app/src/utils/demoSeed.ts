import type {
  AdminSettings,
  CustomerProfile,
  DeliveryPartner,
  FeedbackItem,
  MenuItem,
  OrderRecord,
  ProductReview,
  Store,
  WalletTransaction,
} from '../types/bazar';

export const DEMO_CUSTOMER_UID = 'demo_customer_gb_01';

export const DEMO_PROFILE: CustomerProfile = {
  name: 'Rahul Roy',
  email: 'rahul.roy@gossaigaon.in',
  phone: '9876543210',
  address: 'Station Road, Ward No. 4, Gossaigaon',
  lat: 26.4524,
  lng: 89.9723,
  locationLink: 'https://www.google.com/maps?q=26.4524,89.9723',
  referralCode: 'GBDEMO01',
  walletBalance: 450,
  favorites: { store_1___item_1: true },
  blocked: false,
  createdAt: Date.now() - 86400000,
};

export const DEMO_STORES: Record<string, Store> = {
  store_1: {
    name: 'Gossaigaon Fresh Mart',
    cuisine: 'Vegetables, Fruits & Daily Staples',
    approved: true,
    suspended: false,
    isOpen: true,
    lat: 26.453,
    lng: 89.973,
    storeDiscountPercent: 10,
    storeDiscountMinOrder: 150,
  },
  store_2: {
    name: 'Brahmaputra Dairy & Bakery',
    cuisine: 'Milk, Paneer, Eggs & Snacks',
    approved: true,
    suspended: false,
    isOpen: true,
    lat: 26.451,
    lng: 89.971,
    storeDiscountPercent: 0,
    storeDiscountMinOrder: 0,
  },
};

export const DEMO_MENUS: Record<string, Record<string, Omit<MenuItem, 'itemId' | 'storeId'>>> = {
  store_1: {
    item_1: {
      name: 'Farm Fresh Red Tomato (Tamatar)',
      description: '1 kg Fresh Local Produce',
      searchKeywords: 'tomato tamatar veg sabzi',
      category: 'VEG',
      price: 38,
      mrp: 50,
      isOnSale: true,
      available: true,
      adminApproved: true,
      ratingAvg: 4.8,
      ratingCount: 14,
    },
    item_2: {
      name: 'Aashirvaad Shudh Chakki Atta',
      description: '5 kg Whole Wheat Flour',
      searchKeywords: 'atta flour wheat chakki',
      category: 'STAPLES',
      price: 225,
      mrp: 255,
      available: true,
      adminApproved: true,
      ratingAvg: 4.9,
      ratingCount: 22,
    },
    item_3: {
      name: 'Fortune Kachi Ghani Mustard Oil',
      description: '1 Litre Pouch',
      searchKeywords: 'oil mustard tel fortune',
      category: 'OIL_MASALA',
      price: 148,
      mrp: 170,
      isOnSale: true,
      available: true,
      adminApproved: true,
      ratingAvg: 4.7,
      ratingCount: 9,
    },
  },
  store_2: {
    item_4: {
      name: 'Amul Taaza Toned Milk',
      description: '500 ml Tetra Pack',
      searchKeywords: 'milk doodh amul dairy',
      category: 'DAIRY',
      price: 28,
      mrp: 30,
      available: true,
      adminApproved: true,
      ratingAvg: 4.9,
      ratingCount: 31,
    },
    item_5: {
      name: 'Maggi 2-Minute Masala Noodles',
      description: '280 g Family Pack',
      searchKeywords: 'maggi noodles snacks',
      category: 'SNACKS',
      price: 54,
      mrp: 60,
      available: true,
      adminApproved: true,
      ratingAvg: 4.8,
      ratingCount: 18,
    },
  },
};

export const DEMO_RIDERS: Record<string, DeliveryPartner> = {
  rider_1: {
    name: 'Bikash Das',
    phone: '9864011223',
    vehicle: 'Hero Splendor',
    approved: true,
    online: true,
    suspended: false,
    lat: 26.454,
    lng: 89.974,
    ratingAvg: 4.9,
    ratingCount: 42,
    lastLocationUpdate: Date.now() - 15000,
  },
};

export const DEMO_ORDERS: Record<string, Omit<OrderRecord, 'orderId'>> = {
  ord_demo_1: {
    batchGroupId: 'COMBO_981234',
    customerUid: DEMO_CUSTOMER_UID,
    restaurantId: 'store_1',
    deliveryUid: 'rider_1',
    riderLat: 26.454,
    riderLng: 89.974,
    items: [
      {
        itemId: 'item_1',
        name: 'Farm Fresh Red Tomato (Tamatar)',
        price: 38,
        qty: 2,
        imageUrl: '',
        storeId: 'store_1',
        storeName: 'Gossaigaon Fresh Mart',
      },
    ],
    totalAmount: 76,
    address: 'Station Road, Ward No. 4, Gossaigaon',
    phone: '9876543210',
    customerLat: 26.4524,
    customerLng: 89.9723,
    deliveryOtp: '4829',
    status: 'OUT_FOR_DELIVERY',
    paymentMode: 'COD',
    placedAt: Date.now() - 420000,
    statusTimestamps: {
      PLACED: Date.now() - 420000,
      PREPARING: Date.now() - 360000,
      PACKING: Date.now() - 240000,
      OUT_FOR_DELIVERY: Date.now() - 120000,
    },
    createdAt: Date.now() - 420000,
  },
  ord_demo_2: {
    batchGroupId: 'COMBO_845120',
    customerUid: DEMO_CUSTOMER_UID,
    restaurantId: 'store_2',
    deliveryUid: 'rider_1',
    items: [
      {
        itemId: 'item_4',
        name: 'Amul Taaza Toned Milk',
        price: 28,
        qty: 2,
        imageUrl: '',
        storeId: 'store_2',
        storeName: 'Brahmaputra Dairy & Bakery',
      },
      {
        itemId: 'item_5',
        name: 'Maggi 2-Minute Masala Noodles',
        price: 54,
        qty: 1,
        imageUrl: '',
        storeId: 'store_2',
        storeName: 'Brahmaputra Dairy & Bakery',
      },
    ],
    totalAmount: 110,
    address: 'Station Road, Ward No. 4, Gossaigaon',
    phone: '9876543210',
    deliveryOtp: '7319',
    status: 'DELIVERED',
    paymentMode: 'WALLET',
    riderRating: 5,
    productsReviewed: true,
    createdAt: Date.now() - 86400000,
  },
  ord_demo_3: {
    batchGroupId: 'COMBO_732098',
    customerUid: DEMO_CUSTOMER_UID,
    restaurantId: 'store_1',
    items: [
      {
        itemId: 'item_3',
        name: 'Fortune Kachi Ghani Mustard Oil',
        price: 148,
        qty: 1,
        imageUrl: '',
        storeId: 'store_1',
        storeName: 'Gossaigaon Fresh Mart',
      },
    ],
    totalAmount: 148,
    address: 'Station Road, Ward No. 4, Gossaigaon',
    phone: '9876543210',
    deliveryOtp: '2190',
    status: 'CANCELLED',
    paymentMode: 'COD',
    createdAt: Date.now() - 172800000,
  },
};

export const DEMO_WALLET_TX: Record<string, WalletTransaction> = {
  tx_demo_1: {
    type: 'CREDIT',
    amount: 25,
    note: 'Welcome Referral Bonus (GBFRIEND)',
    createdAt: Date.now() - 86400000,
  },
  tx_demo_2: {
    type: 'CREDIT',
    amount: 425,
    note: 'UPI Wallet Deposit Verified',
    createdAt: Date.now() - 43200000,
  },
};

export const DEMO_REVIEWS: Record<string, Record<string, Record<string, ProductReview>>> = {
  store_1: {
    item_1: {
      rev_1: {
        customerName: 'Ananya B.',
        rating: 5,
        review: 'Very fresh tomatoes, delivered in 12 minutes!',
        createdAt: Date.now() - 7200000,
      },
    },
  },
};

export const DEMO_FEEDBACKS: Record<string, FeedbackItem> = {};

export const DEMO_ADMIN_SETTINGS: AdminSettings = {
  supportPhone: '9876543210',
  supportWhatsapp: '9876543210',
  supportHours: '6:00 AM - 10:30 PM Daily',
};
