import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildVerifiedUpiUri,
  collectKnownUtrs,
  evaluatePasswordStrength,
  evaluateWalletWithdrawalSafety,
  getAuthLockoutRemainingSec,
  isForbiddenObjectKey,
  mapAuthErrorSafe,
  reconcileCartWithCatalog,
  recordAuthAttemptState,
  requiresStrictEmailVerification,
  sanitizeInputBounded,
  sanitizeSafeUrl,
  sanitizeStoredCartItems,
  validateUpiUtr,
} from './security';
import type { Store } from '../types/bazar';

test('blocks prototype pollution keys, unsafe URLs, and script injection payloads', () => {
  assert.equal(isForbiddenObjectKey('__proto__'), true);
  assert.equal(isForbiddenObjectKey('constructor'), true);
  assert.equal(isForbiddenObjectKey('store_1'), false);

  assert.equal(
    sanitizeInputBounded('<script>alert(1)</script>javascript:steal()\x00', 50),
    'scriptalert(1)/scriptsteal()'
  );

  assert.equal(sanitizeSafeUrl('javascript:alert(1)'), '');
  assert.equal(sanitizeSafeUrl('data:text/html,<script>alert(1)</script>', true), '');
  assert.equal(sanitizeSafeUrl('data:image/svg+xml;base64,PHN2Zz4=', true), '');
  assert.equal(sanitizeSafeUrl('data:image/png;base64,iVBORw0KGgo=', true), 'data:image/png;base64,iVBORw0KGgo=');
  assert.equal(sanitizeSafeUrl('https://cdn.example.com/milk.png'), 'https://cdn.example.com/milk.png');
  assert.equal(sanitizeSafeUrl('//evil.com/phish.png'), '');
});

test('validateUpiUtr blocks fake repeated/sequential UTRs and duplicate UTR replay scams', () => {
  assert.equal(validateUpiUtr('431982741052').valid, true);
  assert.equal(validateUpiUtr('12345').valid, false);
  assert.equal(validateUpiUtr('43198274105A').valid, false);
  assert.equal(validateUpiUtr('000000000000').valid, false);
  assert.equal(validateUpiUtr('999999999999').valid, false);
  assert.equal(validateUpiUtr('123456789012').valid, false);
  assert.equal(validateUpiUtr('987654321098').valid, false);

  const used = collectKnownUtrs(
    {
      o1: {
        customerUid: 'u1',
        restaurantId: 's1',
        items: [],
        totalAmount: 100,
        status: 'PLACED',
        transactionId: '431982741052',
      },
    },
    ['551122334455']
  );
  const replay = validateUpiUtr('431982741052', used);
  assert.equal(replay.valid, false);
  assert.ok(replay.reason?.includes('already been used'));
  assert.equal(validateUpiUtr('551122334455', used).valid, false);
});

test('buildVerifiedUpiUri rejects malformed merchant VPAs and out-of-range amounts', () => {
  const ok = buildVerifiedUpiUri({
    payeeVpa: 'gossaigaonbazar@apl',
    payeeName: 'Gossaigaon Bazar',
    amount: 245.5,
  });
  assert.ok(ok?.startsWith('upi://pay?pa=gossaigaonbazar%40apl'));
  assert.equal(
    buildVerifiedUpiUri({ payeeVpa: 'scammer-invalid', payeeName: 'Scam', amount: 100 }),
    null
  );
  assert.equal(
    buildVerifiedUpiUri({ payeeVpa: 'gossaigaonbazar@apl', payeeName: 'Scam', amount: -50 }),
    null
  );
});

test('sanitizeStoredCartItems and reconcileCartWithCatalog stop price tampering', () => {
  const sanitized = sanitizeStoredCartItems([
    {
      itemId: 'item_1',
      storeId: 'store_1',
      name: 'Fresh <b>Tomato</b>',
      price: 1,
      qty: 2,
      imageUrl: 'javascript:alert(1)',
      storeName: 'Fresh Mart',
    },
    {
      itemId: '__proto__',
      storeId: 'store_1',
      name: 'Bad',
      price: 10,
      qty: 1,
      imageUrl: '',
      storeName: 'Bad',
    },
  ]);

  assert.equal(sanitized.length, 1);
  assert.equal(sanitized[0].imageUrl, '');
  assert.equal(sanitized[0].name, 'Fresh bTomato/b');

  const stores: Record<string, Store> = {
    store_1: { name: 'Gossaigaon Fresh Mart', approved: true, isOpen: true },
  };
  const menus = {
    store_1: {
      item_1: { name: 'Farm Fresh Red Tomato', price: 38, available: true, adminApproved: true },
    },
  };

  const reconciled = reconcileCartWithCatalog(sanitized, stores, menus);
  assert.equal(reconciled.tamperedCount, 1);
  assert.equal(reconciled.removedCount, 0);
  assert.equal(reconciled.safeCart[0].price, 38);
  assert.equal(reconciled.safeCart[0].name, 'Farm Fresh Red Tomato');
});

test('password strength, login brute-force lockout, and safe auth error mapping work properly', () => {
  assert.equal(evaluatePasswordStrength('123456').valid, false);
  assert.equal(evaluatePasswordStrength('password123').valid, false);
  assert.equal(evaluatePasswordStrength('abcdefgh').valid, false);
  assert.equal(evaluatePasswordStrength('bazar2026').valid, true);
  assert.equal(evaluatePasswordStrength('Gossaigaon@2026').label, 'Strong');

  let state = { failedCount: 0, lockedUntil: 0, lockoutTier: 0 };
  const t0 = 1_700_000_000_000;
  for (let i = 0; i < 4; i += 1) {
    state = recordAuthAttemptState(state, false, t0);
    assert.equal(getAuthLockoutRemainingSec(state, t0), 0);
  }
  state = recordAuthAttemptState(state, false, t0);
  assert.equal(getAuthLockoutRemainingSec(state, t0), 30);

  state = recordAuthAttemptState(state, true, t0 + 40_000);
  assert.equal(state.failedCount, 0);
  assert.equal(getAuthLockoutRemainingSec(state, t0 + 40_000), 0);

  assert.equal(
    mapAuthErrorSafe(new Error('Firebase: Error (auth/user-not-found).'), 'login'),
    'Invalid email or password. Please verify and try again.'
  );
  assert.ok(
    mapAuthErrorSafe(new Error('Firebase: Error (auth/popup-blocked).'), 'google').includes('blocked')
  );
  assert.ok(
    mapAuthErrorSafe(new Error('Firebase: Error (auth/unauthorized-domain).'), 'google').includes('authorized')
  );
});

test('requiresStrictEmailVerification gates unverified password users while allowing verified, Google, and demo users', () => {
  assert.equal(requiresStrictEmailVerification({ isDemoMode: true, user: null }), false);
  assert.equal(
    requiresStrictEmailVerification({
      isDemoMode: false,
      user: { emailVerified: false, providerData: [{ providerId: 'password' }] },
    }),
    true
  );
  assert.equal(
    requiresStrictEmailVerification({
      isDemoMode: false,
      user: { emailVerified: true, providerData: [{ providerId: 'password' }] },
    }),
    false
  );
  assert.equal(
    requiresStrictEmailVerification({
      isDemoMode: false,
      user: { emailVerified: false, providerData: [{ providerId: 'google.com' }] },
    }),
    false
  );
});

test('evaluateWalletWithdrawalSafety blocks rapid duplicate withdrawals and invalid amounts', () => {
  const now = 1_700_000_100_000;
  const rapid = evaluateWalletWithdrawalSafety({
    amount: 100,
    balance: 500,
    minWithdraw: 50,
    maxWithdraw: 5000,
    upiId: '9876543210@paytm',
    lastWithdrawAt: now - 15_000,
    now,
  });
  assert.equal(rapid.allowed, false);
  assert.ok(rapid.reason?.includes('cooldown'));

  const ok = evaluateWalletWithdrawalSafety({
    amount: 100,
    balance: 500,
    minWithdraw: 50,
    maxWithdraw: 5000,
    upiId: '9876543210@paytm',
    lastWithdrawAt: now - 90_000,
    now,
  });
  assert.equal(ok.allowed, true);
});
